# LootBox — имэйл баталгаажуулалт нэгтгэсэн хувилбар

Энэ бол таны анх илгээсэн **Monshuu2.html** (LootBox) сайт дээр 6 оронтой
имэйл баталгаажуулах алхмыг шууд нэгтгэсэн бүрэн хувилбар. Firebase Auth-ийн
логик хэвээрээ, зөвхөн **"Бүртгүүлэх" товч дарахад** Firebase дээр бодит
хэрэглэгч үүсгэхийн өмнө нэг завсрын алхам нэмэгдсэн:

```
Бүртгүүлэх товч дарна
   -> Talбарууд шалгагдана (нэр, имэйл, нууц үг)
   -> Имэйл өмнө нь бүртгэлтэй эсэхийг Firebase-с шалгана
   -> /api/send-code : 6 оронтой код үүсгэж, Resend-ээр имэйлээр илгээж,
      Upstash Redis-д 5 минутын хугацаатай хадгална
   -> Хэрэглэгч кодоо оруулна (шинэ "Баталгаажуулах" панель)
   -> /api/verify-code : кодыг шалгана
   -> Зөвхөн код зөв бол firebase.auth().createUserWithEmailAndPassword(...)
      дуудагдаж, бодит бүртгэл үүснэ
```

## Юу өөрчлөгдсөн бэ (index.html дотор)

- **CSS**: `.otp-row` — 6 нүдэн код оруулах талбарын загвар (сайтын одоо байгаа
  `--gold-300`, `--bg-elevated` зэрэг CSS хувьсагчийг ашигласан тул Цагаан/
  Неон загвар сонгосон үед ч автоматаар зохицно).
- **HTML**: Нэвтрэх/Бүртгүүлэх/Нууц үг мартсан панелийн хажууд шинэ
  **`#verifyPanel`** нэмэгдсэн (яг адилхан markup хэв маягаар).
- **JS**:
  - `doRegister()` — өмнө нь шууд Firebase дээр бүртгэдэг байсныг, одоо эхлээд
    имэйл availability шалгаад, дараа нь код илгээхээр өөрчилсөн.
  - `requestVerificationCode(email)` — `/api/send-code` рүү дуудна.
  - `finishRegisterAfterVerification()` — өмнөх Firebase бүртгэлийн логикийг
    (createUserWithEmailAndPassword гэх мэт) энд шилжүүлсэн, зөвхөн код зөв
    шалгагдсаны дараа ажиллана.
  - `doVerifyCode()` — `/api/verify-code` рүү дуудаж, зөв бол дээрхийг дуудна.
  - `doResendCode()` / `startResendCooldown()` — 60 секундын cooldown-той код
    дахин илгээх.
  - OTP-ийн 6 нүдэнд авто-шилжилт, buцах, paste дэмжлэг нэмэгдсэн.

Нэвтрэх (`doLogin`), Google-ээр нэвтрэх/бүртгүүлэх, нууц үг сэргээх зэрэг бусад
бүх функц **өөрчлөгдөөгүй**, хэвээрээ ажиллана.

## Файлын бүтэц

```
site/
├── index.html            Таны бүх сайт (одоо verify-panel нэмэгдсэн)
├── api/
│   ├── send-code.js       Код үүсгэж имэйлээр илгээнэ (Resend)
│   └── verify-code.js     Кодыг шалгана
├── package.json
└── .env.example
```

> **Анхаар:** `index.html` дотор `<img src="Logo.PNG">` гэж лого зурагаа
> дуудаж байгаа тул `Logo.PNG` файлаа энэ project-ийн үндсэн (root) хавтас руу
> хуулж, GitHub-д хамт хийж явуулаарай.

## Deploy хийх алхамууд

### 1. Resend
1. https://resend.com дээр бүртгүүлж `RESEND_API_KEY` авна.
2. Жинхэнэ ашиглалтад `api/send-code.js`-ийн `from` талбарыг өөрийн
   баталгаажуулсан домайнаар (Resend -> Domains) солино.

### 2. GitHub
```bash
git init
git add .
git commit -m "Имэйл баталгаажуулалт нэгтгэсэн LootBox"
git branch -M main
git remote add origin https://github.com/<таны-нэр>/lootbox.git
git push -u origin main
```

### 3. Vercel
1. https://vercel.com -> **Add New -> Project** -> дээрх repo-г сонгоно.
2. **Deploy** дарна (Framework Preset: Other, өөрчлөх шаардлагагүй).

### 4. Upstash Redis холбох
Vercel Project -> **Storage** -> **Marketplace Database Providers** ->
**Upstash** -> шинэ Redis database үүсгэнэ. Холбогдмогц `KV_REST_API_URL`
болон `KV_REST_API_TOKEN` автоматаар Environment Variables-д нэмэгдэнэ.

### 5. Environment Variables
Vercel Project -> **Settings -> Environment Variables**:

| Key | Утга |
|---|---|
| `RESEND_API_KEY` | Resend-с авсан түлхүүр |
| `KV_REST_API_URL` | Upstash холбогдоход автоматаар орсон |
| `KV_REST_API_TOKEN` | Upstash холбогдоход автоматаар орсон |

Нэмсний дараа **Redeploy** хийнэ.

## Локал турших

```bash
npm install
npm install -g vercel
vercel dev
```
`.env.example`-г хуулж `.env` болгоод Resend/Upstash-ийн жинхэнэ утгуудаа бичнэ.

## Аюулгүй байдлын тэмдэглэл
- Код 5 минутын дараа автоматаар устана.
- Ижил имэйл рүү 60 секунд тутамд л дахин код авах боломжтой.
- Код таамаглах оролдлого имэйл тус бүрт 5-аар хязгаарлагдсан.
- Код нэг удаа ашиглагдаж, амжилттай баталгаажсны дараа шууд устдаг.
- Имэйл өмнө нь Firebase дээр бүртгэлтэй бол код огт илгээгдэхгүй (spam болон
  хэрэггүй имэйл зарцуулалтаас сэргийлнэ).
