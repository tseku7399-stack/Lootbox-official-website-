// api/send-code.js
// LootBox сайтын index.html дэх "Бүртгүүлэх" товч (doRegister) энэ функцийг
// дуудна. Хэрэглэгчийн имэйл рүү 6 оронтой баталгаажуулах код илгээж,
// уг кодыг Upstash Redis-д 5 минутын хугацаатай (TTL) хадгална.
//
// Шаардлагатай Environment Variables (Vercel Project Settings -> Environment Variables):
//   RESEND_API_KEY        -> Resend dashboard-с авна
//   KV_REST_API_URL        -> Vercel-д Upstash Redis (Marketplace) холбоход автоматаар нэмэгдэнэ
//   KV_REST_API_TOKEN       -> мөн адил автоматаар нэмэгдэнэ

import { Redis } from '@upstash/redis';
import { Resend } from 'resend';

const redis = new Redis({
  url: process.env.KV_REST_API_URL,
  token: process.env.KV_REST_API_TOKEN,
});

const resend = new Resend(process.env.RESEND_API_KEY);

const CODE_TTL_SECONDS = 5 * 60; // 5 минут
const RESEND_COOLDOWN_SECONDS = 60; // ижил имэйл рүү 60 секунд тутамд л дахин код авах боломжтой

function isValidEmail(email) {
  return typeof email === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim());
}

function generateCode() {
  // 100000-999999 хооронд, тэргүүн орон нь 0 болохгүй 6 оронтой код
  return Math.floor(100000 + Math.random() * 900000).toString();
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Зөвхөн POST хүсэлт хүлээн авна' });
  }

  const { email } = req.body || {};

  if (!isValidEmail(email)) {
    return res.status(400).json({ error: 'Имэйл хаяг буруу байна' });
  }

  const normalizedEmail = email.trim().toLowerCase();
  const codeKey = `verify:code:${normalizedEmail}`;
  const cooldownKey = `verify:cooldown:${normalizedEmail}`;

  try {
    // Богино хугацаанд дараалан дарж спам код авахаас сэргийлэх
    const onCooldown = await redis.get(cooldownKey);
    if (onCooldown) {
      return res.status(429).json({
        error: 'Түр хүлээнэ үү. Ойролцоогоор 1 минутын дараа дахин код хүсэх боломжтой.',
      });
    }

    const code = generateCode();

    await redis.set(codeKey, code, { ex: CODE_TTL_SECONDS });
    await redis.set(cooldownKey, '1', { ex: RESEND_COOLDOWN_SECONDS });

    await resend.emails.send({
      // Resend-ийн тестийн домайн: бодит бүтээгдэхүүн дээр өөрийн баталгаажуулсан
      // домайнаар солино (жишээ нь: noreply@tanaidomain.mn)
      from: 'onboarding@resend.dev',
      to: normalizedEmail,
      subject: 'Таны баталгаажуулах код',
      html: `
        <div style="font-family:Arial,Helvetica,sans-serif;max-width:420px;margin:0 auto;padding:32px 24px;color:#1a1a1a;">
          <h2 style="margin:0 0 16px;font-size:20px;">Баталгаажуулах код</h2>
          <p style="margin:0 0 24px;font-size:14px;color:#555;line-height:1.5;">
            Бүртгэлээ баталгаажуулахын тулд доорх кодыг оруулна уу.
          </p>
          <div style="font-size:36px;font-weight:700;letter-spacing:10px;text-align:center;
                      background:#f4f4f6;border-radius:12px;padding:20px 0;margin:0 0 24px;">
            ${code}
          </div>
          <p style="margin:0;font-size:13px;color:#888;line-height:1.5;">
            Энэ код 5 минутын дараа хүчингүй болно. Хэрэв та энэ хүсэлтийг илгээгээгүй бол
            энэ имэйлийг үл тоомсорлоно уу.
          </p>
        </div>
      `,
    });

    return res.status(200).json({ success: true, message: 'Баталгаажуулах код имэйлээр илгээгдлээ' });
  } catch (err) {
    console.error('send-code error:', err);
    return res.status(500).json({ error: 'Код илгээхэд алдаа гарлаа. Дахин оролдоно уу.' });
  }
}
