// api/verify-code.js
// send-code.js-ээс илгээсэн 6 оронтой кодыг шалгана.
// Амжилттай баталгаажвал кодыг Redis-с устгаж, дахин ашиглахаас сэргийлнэ.

import { Redis } from '@upstash/redis';

const redis = new Redis({
  url: process.env.KV_REST_API_URL,
  token: process.env.KV_REST_API_TOKEN,
});

const MAX_ATTEMPTS = 5;
const ATTEMPTS_TTL_SECONDS = 5 * 60; // код хүчинтэй байх хугацаатай ижил

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Зөвхөн POST хүсэлт хүлээн авна' });
  }

  const { email, code } = req.body || {};

  if (!email || !code) {
    return res.status(400).json({ error: 'Имэйл болон код заавал шаардлагатай' });
  }

  const normalizedEmail = String(email).trim().toLowerCase();
  const submittedCode = String(code).trim();

  const codeKey = `verify:code:${normalizedEmail}`;
  const attemptsKey = `verify:attempts:${normalizedEmail}`;

  try {
    const storedCode = await redis.get(codeKey);

    if (!storedCode) {
      return res.status(400).json({
        error: 'Код хугацаа дууссан эсвэл олдсонгүй. Шинэ код авна уу.',
      });
    }

    // Дараалан таамаглах халдлагаас сэргийлж оролдлогын тоог хязгаарлана
    const attempts = await redis.incr(attemptsKey);
    if (attempts === 1) {
      await redis.expire(attemptsKey, ATTEMPTS_TTL_SECONDS);
    }
    if (attempts > MAX_ATTEMPTS) {
      await redis.del(codeKey);
      return res.status(429).json({
        error: 'Хэт олон буруу оролдлого хийлээ. Шинэ код авна уу.',
      });
    }

    if (String(storedCode) !== submittedCode) {
      return res.status(400).json({ error: 'Код буруу байна. Дахин шалгаад оруулна уу.' });
    }

    // Амжилттай — код болон оролдлогын тоог устгана (нэг удаа л ашиглагдана)
    await redis.del(codeKey);
    await redis.del(attemptsKey);

    return res.status(200).json({ success: true, message: 'Имэйл амжилттай баталгаажлаа' });
  } catch (err) {
    console.error('verify-code error:', err);
    return res.status(500).json({ error: 'Баталгаажуулахад алдаа гарлаа. Дахин оролдоно уу.' });
  }
}
