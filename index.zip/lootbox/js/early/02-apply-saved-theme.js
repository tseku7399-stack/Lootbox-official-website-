/* ==================================================================
   02-apply-saved-theme.js — Хадгалсан загвар (dark/light/neon)-ыг хуудас ачаалагдахаас өмнө хэрэглэх
   ================================================================== */

// Хадгалсан тохиргоог (theme) хуудас бүрэн ачаалахаас өмнө аль болох эрт
// хэрэглэж, refresh хийхэд өмнөх сонголт руу шууд орж, "хэвэндээ" (dark)
// рүү нэг агшин ч эргэж харагдахгүй байхаар хийнэ.
(function applySavedThemeEarly(){
  try{
    var saved = JSON.parse(localStorage.getItem('lootbox_settings')) || {};
    if(saved.theme === 'light'){ document.body.classList.add('theme-light'); }
    else if(saved.theme === 'neon'){ document.body.classList.add('theme-neon'); }
  }catch(e){}
})();
