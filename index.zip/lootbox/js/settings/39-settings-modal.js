/* ==================================================================
   39-settings-modal.js — Тохиргооны цонх: загвар, switch-үүд, нэр/нууц үг солих, гарах
   ================================================================== */


// ---- Тохиргоо (Settings) modal: загвар (theme) болон switch-үүдийг
// localStorage-д хадгалж, refresh хийсний дараа ч сонгосон хэвээрээ
// байлгана (өмнө нь хадгалдаггүй байснаас болж "хэвэндээ" (dark, бүх
// switch асаалттай) орж байсан) ----
(function initSettingsModal(){
  var overlay = document.getElementById('settingsModalOverlay');
  var closeBtn = document.getElementById('settingsModalClose');
  var optionDark = document.getElementById('themeOptionDark');
  var optionLight = document.getElementById('themeOptionLight');
  var optionNeon = document.getElementById('themeOptionNeon');
  var SETTINGS_KEY = 'lootbox_settings';
  if(!overlay) return;

  function loadSettings(){
    try{
      return JSON.parse(localStorage.getItem(SETTINGS_KEY)) || {};
    }catch(e){ return {}; }
  }
  function saveSettings(patch){
    var current = loadSettings();
    for(var k in patch){ current[k] = patch[k]; }
    try{ localStorage.setItem(SETTINGS_KEY, JSON.stringify(current)); }catch(e){}
  }

  function closeSettings(){ overlay.classList.remove('open'); }

  closeBtn.addEventListener('click', closeSettings);
  overlay.addEventListener('click', function(e){
    if(e.target === overlay) closeSettings();
  });

  function applyTheme(theme, skipSave){
    document.body.classList.remove('theme-light', 'theme-neon');
    if(theme === 'light'){
      document.body.classList.add('theme-light');
    } else if(theme === 'neon'){
      document.body.classList.add('theme-neon');
    }
    optionDark.classList.toggle('active', theme === 'dark');
    optionLight.classList.toggle('active', theme === 'light');
    optionNeon.classList.toggle('active', theme === 'neon');
    if(!skipSave) saveSettings({ theme: theme });
  }

  optionDark.addEventListener('click', function(){ applyTheme('dark'); });
  optionLight.addEventListener('click', function(){ applyTheme('light'); });
  optionNeon.addEventListener('click', function(){ applyTheme('neon'); });

  // ---- Дарахад доор нь дэлгэрэнгүй хэсэг нээгддэг/хаагддаг мөрүүд
  // (Нууц үг солих, Тусламж) ----
  function wireExpandableRow(rowId, panelId, onOpen){
    var row = document.getElementById(rowId);
    var panel = document.getElementById(panelId);
    if(!row || !panel) return;
    row.addEventListener('click', function(){
      var isOpen = panel.classList.contains('open');
      row.classList.toggle('open', !isOpen);
      panel.classList.toggle('open', !isOpen);
      if(!isOpen && typeof onOpen === 'function') onOpen();
    });
  }
  wireExpandableRow('settingsPasswordRow', 'settingsPasswordPanel');
  wireExpandableRow('settingsHelpRow', 'settingsHelpPanel');

  // ---- Нэвтрээгүй (зочин) үед "Нууц үг солих" гэх мэт зөвхөн бүртгэлтэй
  // хэрэглэгчид зориулагдсан зүйлс Тохиргоонд огт харагдах ёсгүй тул
  // гарчиг/мөр/панелийг бүхэлд нь нуудаг болгов ----
  function renderSettingsAccountVisibility(){
    var loggedIn = !!(typeof currentUser !== 'undefined' && currentUser && currentUser.loggedIn);
    var label = document.getElementById('settingsAccountSectionLabel');
    var row = document.getElementById('settingsPasswordRow');
    var panel = document.getElementById('settingsPasswordPanel');
    if(!loggedIn && panel) panel.classList.remove('open');
    if(!loggedIn && row) row.classList.remove('open');
    if(label) label.style.display = loggedIn ? 'block' : 'none';
    if(row) row.style.display = loggedIn ? 'flex' : 'none';
    if(panel) panel.style.display = loggedIn ? '' : 'none';
  }
  var drawerSettingsLinkEl = document.getElementById('drawerSettingsLink');
  if(drawerSettingsLinkEl) drawerSettingsLinkEl.addEventListener('click', renderSettingsAccountVisibility);
  var profileSettingsBtnEl = document.getElementById('profileSettingsBtn');
  if(profileSettingsBtnEl) profileSettingsBtnEl.addEventListener('click', renderSettingsAccountVisibility);
  renderSettingsAccountVisibility();

  // ---- Нууц үг солих: Firebase дээрх бодит бүртгэлийг эхлээд
  // (reauthenticate) баталгаажуулаад, дараа нь шинэ нууц үгээр
  // солино (Google-ээр нэвтэрсэн бол нууц үг байхгүй тул боломжгүй) ----
  var pwOld = document.getElementById('settingsOldPassword');
  var pwNew = document.getElementById('settingsNewPassword');
  var pwNew2 = document.getElementById('settingsNewPassword2');
  var pwError = document.getElementById('settingsPasswordError');
  var pwSaveBtn = document.getElementById('settingsPasswordSaveBtn');
  if(pwSaveBtn){
    pwSaveBtn.addEventListener('click', function(){
      clearFieldError(pwError);
      var user = (typeof firebase !== 'undefined' && firebase.auth) ? firebase.auth().currentUser : null;
      if(!user){
        setFieldError(pwError, 'Эхлээд бүртгэлээрээ нэвтэрнэ үү.');
        return;
      }
      var hasPasswordProvider = false;
      (user.providerData || []).forEach(function(p){
        if(p.providerId === 'password') hasPasswordProvider = true;
      });
      if(!hasPasswordProvider){
        setFieldError(pwError, 'Та Google-ээр нэвтэрсэн тул нууц үг өөрчлөх боломжгүй.');
        return;
      }
      if(!pwOld.value){
        setFieldError(pwError, 'Хуучин нууц үгээ оруулна уу');
        return;
      }
      if(!pwNew.value || pwNew.value.length < 6){
        setFieldError(pwError, 'Шинэ нууц үг дор хаяж 6 тэмдэгт байх ёстой');
        return;
      }
      if(pwNew.value !== pwNew2.value){
        setFieldError(pwError, 'Шинэ нууц үг таарахгүй байна');
        return;
      }
      pwSaveBtn.disabled = true;
      pwSaveBtn.textContent = 'Хадгалж байна...';
      var cred = firebase.auth.EmailAuthProvider.credential(user.email, pwOld.value);
      user.reauthenticateWithCredential(cred).then(function(){
        return user.updatePassword(pwNew.value);
      }).then(function(){
        pwSaveBtn.disabled = false;
        pwSaveBtn.textContent = 'Хадгалах';
        pwOld.value = '';
        pwNew.value = '';
        pwNew2.value = '';
        document.getElementById('settingsPasswordRow').classList.remove('open');
        document.getElementById('settingsPasswordPanel').classList.remove('open');
        showToast('Нууц үг солигдлоо', '');
      }).catch(function(err){
        pwSaveBtn.disabled = false;
        pwSaveBtn.textContent = 'Хадгалах';
        var msg = 'Алдаа гарлаа, дахин оролдоно уу';
        if(err && err.code === 'auth/wrong-password') msg = 'Хуучин нууц үг буруу байна';
        else if(err && err.code === 'auth/weak-password') msg = 'Шинэ нууц үг дор хаяж 6 тэмдэгт байх ёстой';
        setFieldError(pwError, msg);
      });
    });
  }

  // ---- Аппын өгөгдлийг цэвэрлэх: localStorage-д хадгалагдсан бүх
  // тохиргоо/мэдэгдэл/нэвтрэлтийг устгаад шинээр ачаална (Android-ийн
  // "App info > Clear data" функцтэй адилхан) ----
  var clearDataRow = document.getElementById('settingsClearDataRow');
  if(clearDataRow){
    clearDataRow.addEventListener('click', function(){
      var ok = window.confirm('Энэ үйлдэл таны хадгалсан тохиргоо, мэдэгдэл, нэвтрэлтийн мэдээллийг устгаж, аппыг шинээр эхлүүлнэ. Үргэлжлүүлэх үү?');
      if(!ok) return;
      try{ localStorage.clear(); }catch(e){}
      location.reload();
    });
  }

  // ---- Гарах: profileAuthBtn дээрх одоо байгаа гарах логикийг ашиглана ----
  var settingsLogoutBtn = document.getElementById('settingsLogoutBtn');
  if(settingsLogoutBtn){
    settingsLogoutBtn.addEventListener('click', function(){
      closeSettings();
      var authBtn = document.getElementById('profileAuthBtn');
      if(authBtn && currentUser.loggedIn) authBtn.click();
      else if(!currentUser.loggedIn) showToast('Та аль хэдийн зочны төлөвт байна', '');
    });
  }

  // ---- Хуудас ачаалагдмагц хадгалагдсан тохиргоог сэргээнэ ----
  var saved = loadSettings();
  applyTheme(saved.theme || 'dark', true);
})();
