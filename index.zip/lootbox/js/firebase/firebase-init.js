/* ==================================================================
   firebase-init.js — Firebase-ийг эхлүүлэх (Auth, Analytics, Firestore сангуудын дараа ачаалагдана)
   ================================================================== */

try{
  firebase.initializeApp(firebaseConfig);
}catch(e){}
try{
  if(firebase.analytics) firebase.analytics();
}catch(e){}
