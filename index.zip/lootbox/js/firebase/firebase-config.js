/* ==================================================================
   firebase-config.js — Firebase төслийн тохиргоо (apiKey, projectId г.м)
   ================================================================== */

var firebaseConfig = {
  apiKey: "AIzaSyAHD_aR3yjy9WiKdqqk651O2SoruXuFKlQ",
  authDomain: "lootbox-888888.firebaseapp.com",
  projectId: "lootbox-888888",
  storageBucket: "lootbox-888888.firebasestorage.app",
  messagingSenderId: "484417209328",
  appId: "1:484417209328:web:703967836f332fb0e15335",
  measurementId: "G-0NDEPTF7GW"
};
