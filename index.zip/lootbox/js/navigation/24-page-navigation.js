/* ==================================================================
   24-page-navigation.js — Хуудас хоорондын шилжилт (Бүгдийг харах / Буцах)
   ================================================================== */


// ---- Одоо байсан навигацийн код ----
var seeAllBtn = document.getElementById('seeAllBtn');

var backBtn = document.getElementById('backBtn');

var mainView = document.getElementById('mainView');

var allGamesView = document.getElementById('allGamesView');

var rechargeView = document.getElementById('rechargeView');

var rechargeBackBtn = document.getElementById('rechargeBackBtn');

var rechargeTitle = document.getElementById('rechargeTitle');

var rechargeSub = document.getElementById('rechargeSub');

var rechargeBannerIcon = document.getElementById('rechargeBannerIcon');

var rechargeTotal = document.getElementById('rechargeTotal');

var lastListView = mainView;

seeAllBtn.addEventListener('click', function(){
  mainView.style.display = 'none';
  allGamesView.style.display = 'block';
});

backBtn.addEventListener('click', function(){
  allGamesView.style.display = 'none';
  mainView.style.display = 'block';
});
