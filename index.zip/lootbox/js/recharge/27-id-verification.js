/* ==================================================================
   27-id-verification.js — Цэнэглэх: тоглогчийн ID талбарууд ба баталгаажуулалт
   ================================================================== */


var ZONE_ID_GAMES = ['MLBB', 'Magic Chess'];

var currentRechargeGame = null;

var GAME_NAME_POOLS = {
  'PUBG Mobile': ['ChickenDinner88','GhostRecon_UB','SilentAssassin07','DesertEaglePro','SnowLeopard99','RedZoneRaider','NightOwlSniper','WastelandWolf'],
  'MLBB': ['MythicKing_99','TankMaster88','JungleLord07','SavageStreak_MN','GoldLaneGod','RoamKing22','BurstDamagePro','LegendRankUB'],
  'Roblox': ['xX_Builder123_Xx','RobloxianPro22','PixelCrafter99','SkyBlockKing','NoobMaster69','BlockyHero07','AdoptMePro88','TycoonTitan'],
  'Standoff 2': ['HeadshotKing07','AWP_God_MN','ClutchMaster99','RushBRaider','SmokeGrenadePro','AimGodUB','FlashbangFury','WallbangWizard'],
  'Magic Chess': ['ChessMaster_MN','PawnStorm88','QueenGambit07','RookRusher','KnightRider_99','CheckmateKing','BishopBlitz22','AutoChessPro']
};

function hashSeed(str){
  var hash = 0;
  for(var i = 0; i < str.length; i++){
    hash = (hash << 5) - hash + str.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash);
}

// Тодорхой ID-д зориулсан тогтмол (санамсаргүй бус) хариу — жишээ нь
// PUBG Mobile-ийн 51561693567 ID-г шалгахад үргэлж яг энэ нэр гарна.
var SPECIAL_ACCOUNTS = {
  'PUBG Mobile': {
    '51561693567': { name: 'ツDARK・MAX๛', level: 99 }
  },
  'Standoff 2': {
    '283414789': { name: 'Donk', level: 99 },
    '289587599': { name: 'Femourex', level: 99 },
    '258634452': { name: 'Schizophrenia', level: 99 }
  }
};

function generateMockAccount(game, idValue){
  var special = SPECIAL_ACCOUNTS[game] && SPECIAL_ACCOUNTS[game][idValue];
  if(special) return special;
  var pool = GAME_NAME_POOLS[game];
  var seed = hashSeed((game || '') + ':' + idValue);
  // Valorant дээр Riot ID нь өөрөө нэр тул оруулсан нэрийг нь (# өмнөх хэсгийг) харуулна
  if(game === 'Valorant'){
    return { name: idValue.split('#')[0] || idValue, level: 5 + (seed % 95) };
  }
  var name = pool ? pool[seed % pool.length] : ('Player_' + idValue.slice(-4));
  var level = 5 + (seed % 95);
  return { name: name, level: level };
}

function attachVerifyHandler(){
  var btn = document.getElementById('verifyIdBtn');
  if(!btn) return;
  var input = document.getElementById('playerIdInput');
  var zoneInput = document.getElementById('zoneIdInput');
  var result = document.getElementById('verifyResult');
  // ID эсвэл Zone ID талбарт ямар нэг зүйл бичиж эхлэнгүүт "...оруулна уу"
  // гэсэн өмнөх сануулга (мөн амжилттай шалгасан хуучин үр дүн) шууд
  // арилна — дахин "ID шалгах" дарахыг хүлээхгүй.
  function clearVerifyResult(){
    if(!result.textContent && !result.innerHTML) return;
    result.className = 'verify-result';
    result.innerHTML = '';
  }
  if(input) input.addEventListener('input', clearVerifyResult);
  if(zoneInput) zoneInput.addEventListener('input', clearVerifyResult);
  btn.addEventListener('click', function(){
    var val = input.value.trim();
    var zoneVal = zoneInput ? zoneInput.value.trim() : '';
    var missingId = !val;
    var missingZone = !!zoneInput && !zoneVal;
    if(!missingId && currentRechargeGame === 'Valorant' && !/^.{3,16}#[A-Za-z0-9]{3,5}$/.test(val)){
      result.className = 'verify-result error';
      result.textContent = 'Riot ID-г Name#1234 хэлбэрээр оруулна уу';
      highlightInvalidField(input);
      return;
    }
    if(missingId || missingZone){
      result.className = 'verify-result error';
      if(missingId && missingZone){
        result.textContent = 'ID болон Zone ID хоёуланг нь оруулна уу';
      } else if(missingId){
        result.textContent = 'ID-гаа оруулна уу';
      } else {
        result.textContent = 'Zone ID-гаа оруулна уу';
      }
      if(missingId) highlightInvalidField(input);
      if(missingZone) highlightInvalidField(zoneInput);
      return;
    }
    btn.style.width = btn.offsetWidth + 'px';
    btn.disabled = true;
    btn.innerHTML = '<span class="btn-spinner"></span>';
    result.className = 'verify-result';
    result.textContent = '';
    setTimeout(function(){
      btn.disabled = false;
      btn.textContent = 'ID шалгах';
      btn.style.width = '';
      result.className = 'verify-result success';
      var account = generateMockAccount(currentRechargeGame, val);
      result.innerHTML =
        '<span class="vr-check"><svg viewBox="0 0 24 24" fill="none" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg></span>' +
        '<span class="vr-name">' + account.name + '</span>';
    }, 900);
  });
}

function renderIdFields(game){
  var container = document.getElementById('idFieldsContainer');
  if(ZONE_ID_GAMES.indexOf(game) !== -1){
    container.innerHTML =
      '<div class="id-field id-field-wide">' +
        '<div style="display:flex; gap:10px;">' +
          '<div class="id-field">' +
            '<label>ID оруулах</label>' +
            '<input type="text" inputmode="numeric" pattern="[0-9]*" placeholder="Жишээ: 123456789" id="playerIdInput">' +
          '</div>' +
          '<div class="id-field">' +
            '<label>Zone ID оруулах</label>' +
            '<input type="text" inputmode="numeric" pattern="[0-9]*" placeholder="Жишээ: 2001" id="zoneIdInput">' +
          '</div>' +
        '</div>' +
        '<button type="button" class="verify-btn verify-btn-full" id="verifyIdBtn">ID шалгах</button>' +
        '<div class="verify-result" id="verifyResult"></div>' +
      '</div>';
    attachVerifyHandler();
  } else if(game === 'Valorant'){
    container.innerHTML =
      '<div class="id-field id-field-wide">' +
        '<label>Riot ID оруулах</label>' +
        '<div class="id-verify-row">' +
          '<input type="text" autocapitalize="off" autocomplete="off" spellcheck="false" placeholder="Жишээ: Name#1234" id="playerIdInput">' +
          '<button type="button" class="verify-btn" id="verifyIdBtn">ID шалгах</button>' +
        '</div>' +
        '<div class="verify-result" id="verifyResult"></div>' +
      '</div>';
    attachVerifyHandler();
  } else {
    container.innerHTML =
      '<div class="id-field id-field-wide">' +
        '<label>ID оруулах</label>' +
        '<div class="id-verify-row">' +
          '<input type="text" inputmode="numeric" pattern="[0-9]*" placeholder="Жишээ: 123456789" id="playerIdInput">' +
          '<button type="button" class="verify-btn" id="verifyIdBtn">ID шалгах</button>' +
        '</div>' +
        '<div class="verify-result" id="verifyResult"></div>' +
      '</div>';
    attachVerifyHandler();
  }
}
