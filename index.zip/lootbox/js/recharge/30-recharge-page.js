/* ==================================================================
   30-recharge-page.js — Цэнэглэх хуудас: тоглоом сонгох, баннер, “Худалдаж авах” товч
   ================================================================== */


var rechargeBannerEl = document.getElementById('rechargeBanner');

var DEFAULT_BANNER_BG = 'linear-gradient(135deg,#150b2e,#3a1e6b 60%,var(--ml-purple))';

var RECHARGE_BANNER_BG = {
  'PUBG Mobile': 'Pubgmbanner.PNG',
  'MLBB': 'https://cloud9.gg/wp-content/uploads/1540x480_MLBB.png.webp',
  'Standoff 2': 'Standoff2banner.PNG',
  'Roblox': 'https://devforum-uploads.s3.dualstack.us-east-2.amazonaws.com/uploads/original/4X/4/3/7/43736e1e26e5a6bc010d68dee32e4a300f529866.png'
};

document.querySelectorAll('.offer-card').forEach(function(card){
  card.addEventListener('click', function(){
    var game = card.getAttribute('data-game');
    currentRechargeGame = game;
    lastListView = (allGamesView.style.display === 'none') ? mainView : allGamesView;
    lastListView.style.display = 'none';

    rechargeTitle.textContent = card.getAttribute('data-display-name') || game;
    var rechargeHeadTitle = document.getElementById('rechargeHeadTitle');
    if(rechargeHeadTitle) rechargeHeadTitle.textContent = card.getAttribute('data-display-name') || game;
    rechargeSub.textContent = siteRechargeSubtitle;
    var cover = card.querySelector('.offer-cover');
    rechargeBannerIcon.innerHTML = cover ? cover.innerHTML : '';

    if(RECHARGE_BANNER_BG[game]){
      rechargeBannerEl.style.backgroundImage =
        'linear-gradient(135deg, rgba(21,11,46,0.62), rgba(58,30,107,0.48) 55%, rgba(124,77,255,0.35)), url(\'' + RECHARGE_BANNER_BG[game] + '\')';
      rechargeBannerEl.style.backgroundSize = 'cover';
      rechargeBannerEl.style.backgroundPosition = 'center';
    } else {
      rechargeBannerEl.style.backgroundImage = DEFAULT_BANNER_BG;
      rechargeBannerEl.style.backgroundSize = '';
      rechargeBannerEl.style.backgroundPosition = '';
    }

    renderIdFields(game);
    renderPackages(game);

    rechargeTotal.textContent = '—';
    var checkoutBarReset = document.getElementById('rechargeCheckoutBar');
    if(checkoutBarReset) checkoutBarReset.classList.remove('is-sticky');
    var rechargeWarningReset = document.querySelector('.recharge-warning');
    if(rechargeWarningReset) rechargeWarningReset.style.display = '';

    rechargeView.style.display = 'block';
  });
});

rechargeBackBtn.addEventListener('click', function(){
  rechargeView.style.display = 'none';
  lastListView.style.display = 'block';
});

var rechargeBuyBtn = document.getElementById('rechargeBuyBtn');

rechargeBuyBtn.addEventListener('click', function(){
  if(!currentUser.loggedIn){
    openLogin('recharge');
    return;
  }
  var playerIdEl = document.getElementById('playerIdInput');
  if(playerIdEl && !playerIdEl.value.trim()){
    highlightInvalidField(playerIdEl);
    return;
  }
  var zoneIdEl = document.getElementById('zoneIdInput');
  if(zoneIdEl && !zoneIdEl.value.trim()){
    highlightInvalidField(zoneIdEl);
    return;
  }
  var selected = document.querySelector('.package-card.selected');
  if (!selected){
    highlightInvalidSection(document.getElementById('packageGrid'));
    return;
  }
  openPaymentModal(selected);
});
