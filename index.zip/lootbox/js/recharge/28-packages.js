/* ==================================================================
   28-packages.js — Цэнэглэх: валютын icon, багцын жагсаалт ба сонголт
   ================================================================== */


var CURRENCY_ICONS = {
  DIAMOND: '<svg viewBox="0 0 24 24"><path d="M4.5 9L12 3l7.5 6-7.5 12z" fill="#af9bf1"/><path d="M8 9l4-6 4 6-4 12z" fill="#e3dbfa"/><path d="M4.5 9h15" stroke="#5b43a7" stroke-width="0.6"/></svg>',
  UC: '<img src="UC.PNG" alt="UC">',
  ROBUX: '<img src="Robux.PNG" alt="ROBUX">',
  GOLD: '<img src="GOLD.png" alt="GOLD">',
  VP: '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="10" fill="#ff4655"/><text x="12" y="15.6" font-size="9.5" font-weight="800" text-anchor="middle" fill="#ffffff" font-family="Arial,sans-serif">VP</text></svg>'
};

var CURRENCY_LABELS = {
  DIAMOND: 'Diamonds',
  UC: 'UC',
  ROBUX: 'Robux',
  GOLD: 'Gold',
  VP: 'VP'
};

var GAME_CURRENCY = {
  'PUBG Mobile': 'UC',
  'Roblox': 'ROBUX',
  'Standoff 2': 'GOLD',
  'Valorant': 'VP'
};

var DEFAULT_PACKAGE_TIERS = [
  { amount:78,   bonus:8,    price:"5'000₮",   img:'https://www.gameshop.mn/78.webp' },
  { amount:156,  bonus:16,   price:"9'600₮",   img:'https://www.gameshop.mn/156.webp' },
  { amount:234,  bonus:23,   price:"13'800₮",  img:'https://www.gameshop.mn/234.webp' },
  { amount:625,  bonus:81,   price:"37'000₮",  img:'https://www.gameshop.mn/625.webp' },
  { amount:1860, bonus:335,  price:"110'800₮", img:'https://www.gameshop.mn/1860.webp' },
  { amount:3099, bonus:589,  price:"184'600₮", img:'https://www.gameshop.mn/3099.webp' },
  { amount:4649, bonus:883,  price:"276'900₮", img:'https://www.gameshop.mn/4649.webp' },
  { amount:7740, bonus:1548, price:"461'500₮", img:'https://www.gameshop.mn/7740.webp' },
  { special:true, label:'TWILIGHT PASS', price:"30'800₮", img:'https://www.gameshop.mn/twilight.png' },
  { special:true, label:'WEEKLY PASS',   price:"5'900₮",  img:'https://www.gameshop.mn/weekly.png' }
];

var GAME_PACKAGE_TIERS = {
  'PUBG Mobile': [
    { amount:60,    bonus:0, price:'5,000₮' },
    { amount:325,   bonus:0, price:'18,000₮' },
    { amount:660,   bonus:0, price:'35,500₮' },
    { amount:1800,  bonus:0, price:'87,000₮' },
    { amount:3850,  bonus:0, price:'170,000₮' },
    { amount:8100,  bonus:0, price:'340,000₮' },
    { amount:16200, bonus:0, price:'670,000₮' }
  ],
  // АНХААР: Valorant-ын үнүүд түр (жишээ) утга. Жинхэнэ үнээ админ самбараас засна уу.
  'Valorant': [
    { amount:475,   bonus:0, price:'25,000₮' },
    { amount:1000,  bonus:0, price:'50,000₮' },
    { amount:2050,  bonus:0, price:'100,000₮' },
    { amount:3650,  bonus:0, price:'175,000₮' },
    { amount:5350,  bonus:0, price:'250,000₮' },
    { amount:11000, bonus:0, price:'500,000₮' }
  ],
  'Standoff 2': [
    { amount:100,  bonus:0, price:'8,000₮',   img:'Gold1.PNG' },
    { amount:500,  bonus:0, price:'28,000₮',  img:'Gold2.PNG' },
    { amount:1000, bonus:0, price:'48,000₮',  img:'Gold3.PNG' },
    { amount:3000, bonus:0, price:'104,000₮', img:'Gold4.PNG' }
  ]
};

function renderPackages(game){
  var currency = GAME_CURRENCY[game] || 'DIAMOND';
  var tiers = GAME_PACKAGE_TIERS[game] || DEFAULT_PACKAGE_TIERS;
  var grid = document.getElementById('packageGrid');
  if(!grid) return;
  var stepTitle = document.getElementById('packageStepTitle');
  if(stepTitle) stepTitle.textContent = (currency === 'DIAMOND' ? 'Diamond' : (CURRENCY_LABELS[currency] || 'Diamond')) + ' багц сонгох';
  grid.innerHTML = tiers.map(function(t){
    var cardClass = 'package-card';
    var badgeHtml = '';
    if(t.badge === 'best'){ cardClass += ' best'; badgeHtml = '<span class="badge best-badge">' + t.badgeLabel + '</span>'; }
    if(t.badge === 'popular'){ cardClass += ' popular'; badgeHtml = '<span class="badge popular-badge">' + t.badgeLabel + '</span>'; }
    var mainLine = t.special ? t.label : (t.amount + (t.bonus ? ' <em>+' + t.bonus + '</em>' : ''));
    var itemText = t.special ? t.label : (t.amount + (t.bonus ? ' +' + t.bonus : '') + ' ' + (CURRENCY_LABELS[currency] || ''));
    // Анхаар: энэ icon нь rechargeView харагдахаас ("display:block" болохоос)
    // ЭРТ innerHTML-ээр DOM-д орж ирдэг тул loading="lazy" ашиглавал зарим
    // browser хараахан харагдаагүй (display:none) элементийг "алс хол" гэж
    // үзэж, зургийг харагдах хүртэл огт татаж эхэлдэггүй — яг тэр үед
    // "орсны дараа гарч ирэх" эффект үүсгэдэг байсан. Тиймээс энд lazy
    // ашиглахгүй, шууд (eager) татуулна.
    var iconHtml = ((currency === 'DIAMOND' || currency === 'GOLD') && t.img)
      ? '<img class="cur-photo" src="' + t.img + '" alt="" decoding="async">'
      : CURRENCY_ICONS[currency];
    return '<div class="' + cardClass + '" data-item="' + itemText + '" data-price="' + t.price + '">' + badgeHtml +
      '<div class="amt"><span class="cur-icon">' + iconHtml + '</span>' + mainLine + '</div>' +
      '<div class="price">' + t.price + '</div></div>';
  }).join('');
  attachPackageHandlers();
}

function attachPackageHandlers(){
  var checkoutBar = document.getElementById('rechargeCheckoutBar');
  var rechargeWarning = document.querySelector('.recharge-warning');
  document.querySelectorAll('.package-card').forEach(function(pkg){
    pkg.addEventListener('click', function(){
      document.querySelectorAll('.package-card').forEach(function(p){ p.classList.remove('selected'); });
      pkg.classList.add('selected');
      var priceEl = pkg.querySelector('.price');
      rechargeTotal.textContent = priceEl ? priceEl.textContent : '—';
      if(checkoutBar) checkoutBar.classList.add('is-sticky');
      // Багц сонгосны дараа "Заавал анхаарах зүйлс" сануулга цаашид
      // шаардлагагүй тул шууд алгасна
      if(rechargeWarning) rechargeWarning.style.display = 'none';
    });
  });
}

attachVerifyHandler();

renderPackages(null);
