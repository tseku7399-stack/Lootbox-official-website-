/* ==================================================================
   01-settings-sound.js — Тохиргоо (localStorage) унших + дууны эффект
   ================================================================== */


// ---- Тохиргоо дотор байгаа 3 унтраа/асаах (Push мэдэгдэл / Дууны эффект /
// Нүүр хуудасны видео тоглуулах)-г бодит ажиллагаанд оруулахад
// ашиглах хуваалцсан функцууд ----
var APP_SETTINGS_KEY = 'lootbox_settings';

function getAppSettings(){
  try{ return JSON.parse(localStorage.getItem(APP_SETTINGS_KEY)) || {}; }catch(e){ return {}; }
}

function isNotifEnabled(){ return getAppSettings().notif !== false; }

function isSoundEnabled(){ return getAppSettings().sound !== false; }

function isAutoplayEnabled(){ return getAppSettings().autoplay !== false; }

function playTone(freq, durationMs, type){
  if(!isSoundEnabled()) return;
  try{
    var Ctx = window.AudioContext || window.webkitAudioContext;
    if(!Ctx) return;
    var ctx = new Ctx();
    var osc = ctx.createOscillator();
    var gain = ctx.createGain();
    osc.type = type || 'sine';
    osc.frequency.value = freq;
    gain.gain.value = 0.08;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + durationMs / 1000);
    osc.stop(ctx.currentTime + durationMs / 1000);
    osc.onended = function(){ try{ ctx.close(); }catch(e){} };
  }catch(e){}
}

function playClickSound(){ playTone(520, 90, 'sine'); }

function playSuccessSound(){
  playTone(660, 120, 'sine');
  setTimeout(function(){ playTone(880, 160, 'sine'); }, 110);
}
