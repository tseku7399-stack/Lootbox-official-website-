/* ==================================================================
   23-profile-edit.js — Профайл засах: нэр өөрчлөх, хадгалах, нэвтрэх/гарах товч
   ================================================================== */


profileBackBtn.addEventListener('click', function(){
  profileView.style.display = 'none';
  if(profileOpenedFrom) profileOpenedFrom.style.display = 'block';
  else document.getElementById('mainView').style.display = 'block';
});

profileUsernameInput.addEventListener('input', function(){
  if(!currentUser.loggedIn) return;
  if(profileUsernameError) clearFieldError(profileUsernameError);
  if(!pendingAvatarImg) renderProfilePreview();
});

profileSaveBtn.addEventListener('click', function(){
  if(!currentUser.loggedIn) return;
  if(profileUsernameError) clearFieldError(profileUsernameError);
  var newName = profileUsernameInput.value.trim();
  if(!newName){
    highlightInvalidField(profileUsernameInput);
    return;
  }
  // ---- Өөр хэрэглэгчийн нэртэй давхцаж байгаа эсэхийг шалгах (өөрийн
  // одоогийн бичлэгийг excludeKey-ээр орхигдуулна, ингэснээр хэрэглэгч
  // өөрийн хуучин нэрээ өөрчлөлгүй дахин хадгалж болно) ----
  if(isUsernameTaken(newName, currentUserKey)){
    if(profileUsernameError) setFieldError(profileUsernameError, 'Энэ хэрэглэгчийн нэр аль хэдийн ашиглагдсан байна');
    highlightInvalidField(profileUsernameInput, profileUsernameError);
    return;
  }
  var prevUsername = currentUser.username;
  var prevAvatarImg = currentUser.avatarImg;
  currentUser.username = newName;
  currentUser.avatarText = getInitials(newName);
  currentUser.avatarImg = pendingAvatarImg;
  var saveOk = true;
  if(currentUserKey){
    var users = loadUsers();
    if(users[currentUserKey]){
      users[currentUserKey].displayName = newName;
      users[currentUserKey].avatarImg = pendingAvatarImg;
      saveOk = saveUsers(users);
    }
  }
  if(!saveOk){
    // Хадгалж чадаагүй тул (жишээ нь: төхөөрөмжийн санах ой дүүрсэн) хуучин утгыг сэргээж,
    // хэрэглэгчид ХУДАЛ "амжилттай" мессеж үзүүлэхгүй байх
    currentUser.username = prevUsername;
    currentUser.avatarImg = prevAvatarImg;
    if(avatarUploadError) setFieldError(avatarUploadError, 'Хадгалж чадсангүй. Төхөөрөмжийн санах ой дүүрсэн байж магадгүй');
    return;
  }
  renderTopbar();
  profileSaveBtn.textContent = 'Хадгалагдлаа ✓';
  profileSaveBtn.classList.add('saved');
  var nameChanged = newName !== prevUsername;
  var avatarChanged = pendingAvatarImg !== prevAvatarImg;
  if(nameChanged && avatarChanged){
    showToast('Профайл шинэчлэгдлээ', 'Нэр болон зураг амжилттай солигдлоо.');
  } else if(avatarChanged){
    showToast('Зураг амжилттай солигдлоо', 'Шинэ профайл зураг хадгалагдлаа.');
  } else if(nameChanged){
    showToast('Нэр амжилттай солигдлоо', 'Шинэ хэрэглэгчийн нэр хадгалагдлаа.');
  } else {
    showToast('Амжилттай хадгалагдлаа', '');
  }

  profileView.style.display = 'none';
  document.getElementById('mainView').style.display = 'block';
});

profileAuthBtn.addEventListener('click', function(){
  if(currentUser.loggedIn){
    // Гарах: зочны төлөвт буцаж, гол нүүр рүү үлдэнэ (заавал нэвтрэх дэлгэц рүү оруулахгүй)
    firebase.auth().signOut().then(function(){
      profileView.style.display = 'none';
      document.getElementById('mainView').style.display = 'block';
      showToast('Амжилттай гарлаа', 'Та зочны төлөвт шилжлээ.');
    });
  } else {
    // Нэвтрэх: профайл дээрээс нэвтэрсний дараа буцаад профайл руугаа орно
    profileOpenedFrom = loginView;
    openLogin('profile');
  }
});
