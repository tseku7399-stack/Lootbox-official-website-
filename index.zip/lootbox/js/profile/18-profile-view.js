/* ==================================================================
   18-profile-view.js — Профайл хуудас: элементүүд, зурах функцууд, нээх
   ================================================================== */


// ---- Профайл ----
var profileView = document.getElementById('profileView');

var profileBackBtn = document.getElementById('profileBackBtn');

var profileUsernameInput = document.getElementById('profileUsernameInput');

var profileUsernameField = document.getElementById('profileUsernameField');

var profileUsernameError = document.getElementById('profileUsernameError');

var profileEmailInput = document.getElementById('profileEmailInput');

var profileEmailField = document.getElementById('profileEmailField');

var profileHistorySection = document.getElementById('profileHistorySection');

var profileHistoryTabs = document.getElementById('profileHistoryTabs');

var profileHistoryTotal = document.getElementById('profileHistoryTotal');

var profileHistoryList = document.getElementById('profileHistoryList');

var currentHistoryTab = 'success';

var profileAvatarPreview = document.getElementById('profileAvatarPreview');

var avatarEditBtn = document.getElementById('avatarEditBtn');

var avatarFileInput = document.getElementById('avatarFileInput');

var profileSaveBtn = document.getElementById('profileSaveBtn');

var profileAuthBtn = document.getElementById('profileAuthBtn');

var profileLockedMsg = document.getElementById('profileLockedMsg');

var pendingAvatarImg = null;

var profileOpenedFrom = null;

function renderProfilePreview(){
  if(pendingAvatarImg){
    profileAvatarPreview.innerHTML = '';
    var img = document.createElement('img');
    img.src = pendingAvatarImg;
    profileAvatarPreview.appendChild(img);
  } else {
    profileAvatarPreview.textContent = getInitials(profileUsernameInput.value || currentUser.username);
  }
}

function renderProfileAuthBtn(){
  if(currentUser.loggedIn){
    profileAuthBtn.textContent = 'Гарах';
  } else {
    profileAuthBtn.textContent = 'Нэвтрэх';
  }
}

function renderProfileLockState(){
  var locked = !currentUser.loggedIn;
  profileLockedMsg.style.display = locked ? 'block' : 'none';
  avatarEditBtn.style.display = locked ? 'none' : 'flex';
  profileUsernameField.style.display = locked ? 'none' : 'block';
  profileEmailField.style.display = locked ? 'none' : 'block';
  profileSaveBtn.style.display = locked ? 'none' : 'block';
  profileHistorySection.style.display = locked ? 'none' : 'block';
}

function getCurrentRecord(){
  if(!currentUserKey) return null;
  var users = loadUsers();
  return users[currentUserKey] || null;
}

function renderPurchaseHistory(){
  var record = getCurrentRecord();
  var allPurchases = (record && record.purchases) ? record.purchases : [];
  var purchases = allPurchases.filter(function(p){
    var status = p.status === 'success' ? 'success' : 'pending';
    return status === currentHistoryTab;
  });

  var total = purchases.reduce(function(sum, p){
    var num = parseInt(String(p.price || '').replace(/[^0-9]/g, ''), 10);
    return sum + (isNaN(num) ? 0 : num);
  }, 0);
  if(profileHistoryTotal){
    profileHistoryTotal.textContent = 'Нийт дүн: ₮' + total.toLocaleString('en-US');
  }

  if(purchases.length === 0){
    var emptyLabel = currentHistoryTab === 'success' ? 'Амжилттай' : 'Хүлээгдэж буй';
    profileHistoryList.innerHTML = '<div class="profile-history-empty">' + emptyLabel + ' худалдан авалт алга байна</div>';
    return;
  }
  profileHistoryList.innerHTML = purchases.map(function(p){
    var accLine = p.accId ? ('<div class="ph-acc">ID: ' + p.accId + (p.accName ? (' · ' + p.accName) : '') + '</div>') : '';
    var status = p.status === 'success' ? 'success' : 'pending';
    var statusLabel = status === 'success' ? 'Амжилттай' : 'Хүлээгдэж буй';
    var statusBadge = '<div class="ph-status ph-status-' + status + '">' + statusLabel + '</div>';
    return '<div class="profile-history-item">' +
      '<div class="ph-left"><div class="ph-game">' + p.game + '</div>' + accLine + '<div class="ph-item">' + p.item + '</div><div class="ph-date">' + p.date + '</div>' + statusBadge + '</div>' +
      '<div class="ph-price">' + p.price + '</div>' +
    '</div>';
  }).join('');
}

if(profileHistoryTabs){
  profileHistoryTabs.querySelectorAll('.ph-tab').forEach(function(tab){
    tab.addEventListener('click', function(){
      if(tab.classList.contains('active')) return;
      profileHistoryTabs.querySelectorAll('.ph-tab').forEach(function(t){ t.classList.remove('active'); });
      tab.classList.add('active');
      currentHistoryTab = tab.getAttribute('data-status');
      renderPurchaseHistory();
    });
  });
}

function openProfile(){
  var mv = document.getElementById('mainView');
  var agv = document.getElementById('allGamesView');
  // Хэрэв нэвтрэх хуудаснаас буцаж ирсэн бол өмнөх харагдаж байсан хуудас руу буцна
  if(profileOpenedFrom !== loginView){
    profileOpenedFrom = (agv.style.display !== 'none') ? agv : mv;
  }
  showAllPagesHidden();

  profileUsernameInput.value = currentUser.username;
  profileEmailInput.value = currentUser.email || '';
  pendingAvatarImg = currentUser.avatarImg;
  if(avatarUploadError) clearFieldError(avatarUploadError);
  if(profileUsernameError) clearFieldError(profileUsernameError);
  renderProfilePreview();
  profileSaveBtn.textContent = 'Хадгалах';
  profileSaveBtn.classList.remove('saved');
  renderProfileAuthBtn();
  renderProfileLockState();
  renderPurchaseHistory();

  profileView.style.display = 'block';
}

function handleOpenProfileClick(){
  if(currentUser.loggedIn){
    profileOpenedFrom = null;
    openProfile();
  } else {
    profileOpenedFrom = document.getElementById('mainView');
    openLogin('main');
  }
}

var navbarProfileBtn = document.getElementById('navbarProfileBtn');

if(navbarProfileBtn){
  navbarProfileBtn.addEventListener('click', handleOpenProfileClick);
}
