/* ==================================================================
   22-avatar-upload.js — Профайл зураг (avatar) сонгох, жижгэрүүлж хадгалах
   ================================================================== */


avatarEditBtn.addEventListener('click', function(){
  if(!currentUser.loggedIn) return;
  avatarFileInput.click();
});

var avatarUploadError = document.getElementById('avatarUploadError');

var AVATAR_MAX_BYTES = 100 * 1024 * 1024; // 100MB (сонгож болох файлын дээд хэмжээ; хадгалахын өмнө 256px болгож шахдаг тул эх файл том байсан ч болно)

// Профайлын зургийг localStorage-д хадгалахаас өмнө жижигрүүлж, JPEG болгон
// шахна. localStorage-ийн нийт хэмжээ ихэвчлэн 5-10MB байдаг тул камерын
// 2-3MB-тай анхны зургийг шахалтгүйгээр шууд хадгалахыг оролдвол хэмжээ
// амархан хэтэрч, "Хадгалж чадсангүй" алдаа гардаг байсан. Одоо хамгийн ихдээ
// 256px, JPEG 85% чанартайгаар хадгалснаар зураг ихэвчлэн ердөө хэдхэн
// арван KB болж, энэ алдаа бараг гарахгүй болно.
var AVATAR_MAX_DIM = 256;

function resizeAvatarDataUrl(sourceDataUrl, onDone, onFail){
  var img = new Image();
  img.onload = function(){
    var w = img.naturalWidth, h = img.naturalHeight;
    if(!w || !h){ onFail(); return; }
    var scale = Math.min(1, AVATAR_MAX_DIM / Math.max(w, h));
    var outW = Math.max(1, Math.round(w * scale));
    var outH = Math.max(1, Math.round(h * scale));
    try{
      // Эх зураг том байхад (жишээ нь дэвсгэр камерын 4000px зураг) нэг
      // алхмаар шууд 256px рүү багасгахад canvas сайн чанартайгаар ч
      // сорвижиж бүрсэлздэг (downscale artifact) тул хагасаар нь
      // дараалан багасгаж, эцэст нь high-quality smoothing ашиглан эцсийн
      // хэмжээнд оруулна — ингэснээр profile зураг эрс тодорхой болно.
      var curCanvas = document.createElement('canvas');
      curCanvas.width = w;
      curCanvas.height = h;
      var curCtx = curCanvas.getContext('2d');
      curCtx.imageSmoothingEnabled = true;
      if('imageSmoothingQuality' in curCtx) curCtx.imageSmoothingQuality = 'high';
      curCtx.drawImage(img, 0, 0, w, h);

      var curW = w, curH = h;
      while(curW * 0.5 > outW && curH * 0.5 > outH){
        var nextW = Math.max(outW, Math.round(curW * 0.5));
        var nextH = Math.max(outH, Math.round(curH * 0.5));
        var stepCanvas = document.createElement('canvas');
        stepCanvas.width = nextW;
        stepCanvas.height = nextH;
        var stepCtx = stepCanvas.getContext('2d');
        stepCtx.imageSmoothingEnabled = true;
        if('imageSmoothingQuality' in stepCtx) stepCtx.imageSmoothingQuality = 'high';
        stepCtx.drawImage(curCanvas, 0, 0, curW, curH, 0, 0, nextW, nextH);
        curCanvas = stepCanvas;
        curW = nextW; curH = nextH;
      }

      var canvas = document.createElement('canvas');
      canvas.width = outW;
      canvas.height = outH;
      var ctx = canvas.getContext('2d');
      ctx.imageSmoothingEnabled = true;
      if('imageSmoothingQuality' in ctx) ctx.imageSmoothingQuality = 'high';
      ctx.drawImage(curCanvas, 0, 0, curW, curH, 0, 0, outW, outH);
      onDone(canvas.toDataURL('image/jpeg', 0.92));
    }catch(e){
      onFail();
    }
  };
  img.onerror = onFail;
  img.src = sourceDataUrl;
}

avatarFileInput.addEventListener('change', function(){
  if(!currentUser.loggedIn) return;
  if(avatarUploadError) clearFieldError(avatarUploadError);
  var file = avatarFileInput.files && avatarFileInput.files[0];
  if(!file) return;
  if(file.type.indexOf('image/') !== 0){
    if(avatarUploadError) setFieldError(avatarUploadError, 'Зөвхөн зургийн файл (JPG, PNG г.м) оруулна уу');
    avatarFileInput.value = '';
    return;
  }
  if(file.size > AVATAR_MAX_BYTES){
    if(avatarUploadError) setFieldError(avatarUploadError, 'Зургийн хэмжээ 100MB-с хэтэрсэн байна. Жижиг зураг сонгоно уу');
    avatarFileInput.value = '';
    return;
  }
  var reader = new FileReader();
  reader.onload = function(e){
    resizeAvatarDataUrl(e.target.result, function(smallDataUrl){
      pendingAvatarImg = smallDataUrl;
      renderProfilePreview();
      avatarFileInput.value = '';
    }, function(){
      if(avatarUploadError) setFieldError(avatarUploadError, 'Зургийг уншиж чадсангүй. Дахин оролдоно уу');
      avatarFileInput.value = '';
    });
  };
  reader.onerror = function(){
    if(avatarUploadError) setFieldError(avatarUploadError, 'Зургийг уншиж чадсангүй. Дахин оролдоно уу');
    avatarFileInput.value = '';
  };
  reader.readAsDataURL(file);
});
