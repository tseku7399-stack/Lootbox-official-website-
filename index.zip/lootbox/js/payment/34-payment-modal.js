/* ==================================================================
   34-payment-modal.js — Төлбөрийн цонх: нээх / хаах / QPay-Шилжүүлэг таб
   ================================================================== */


function switchPaymentTab(tab){
  var isQpay = tab === 'qpay';
  pmTabQpay.classList.toggle('active', isQpay);
  pmTabBank.classList.toggle('active', !isQpay);
  pmPanelQpay.style.display = isQpay ? 'block' : 'none';
  pmPanelBank.style.display = isQpay ? 'none' : 'block';
}

pmTabQpay.addEventListener('click', function(){ switchPaymentTab('qpay'); });

pmTabBank.addEventListener('click', function(){ switchPaymentTab('bank'); });

function openPaymentModal(selectedPackageEl){
  // Төлбөр боловсруулагдаж байхад цонхыг санамсаргүй хаасан бол дахин нээхэд
  // шинээр эхлүүлэлгүй, явж буй loading-ийг үргэлжлүүлэн харуулна.
  if(paymentProcessing){
    paymentModalOverlay.classList.add('open');
    return;
  }
  pendingSelectedPackage = selectedPackageEl;
  switchPaymentTab('qpay');

  var gameName = rechargeTitle.textContent || '';
  var itemText = selectedPackageEl.getAttribute('data-item') || '';
  var priceText = selectedPackageEl.getAttribute('data-price') || '';
  pmGameName.textContent = gameName;
  pmItemName.textContent = itemText;

  var playerIdEl = document.getElementById('playerIdInput');
  var zoneIdEl = document.getElementById('zoneIdInput');
  var idValue = playerIdEl ? playerIdEl.value.trim() : '';
  var zoneValue = zoneIdEl ? zoneIdEl.value.trim() : '';
  var idDisplay = idValue + (zoneValue ? ' (' + zoneValue + ')' : '');
  var accountName = idValue ? generateMockAccount(currentRechargeGame, idValue).name : '';
  pmAccInfo.textContent = idValue ? ('ID: ' + idDisplay + (accountName ? (' · ' + accountName) : '')) : '—';

  pmTotalAmount.textContent = priceText;
  transferAmount.textContent = priceText;

  var memoIdPart = (idValue || 'GUEST').toUpperCase().replace(/[^A-Z0-9]/g, '');
  var memoStamp = Date.now().toString(36).toUpperCase().slice(-5);
  currentTransferMemo = 'LB-' + memoIdPart + '-' + memoStamp;
  transferMemo.textContent = currentTransferMemo;
  transferMemoCopyBtn.classList.remove('copied');
  transferMemoCopyBtn.textContent = 'Хуулах';

  selectTransferBank(BANK_APPS[0], null);
  transferBankChips.querySelectorAll('.transfer-chip')[0].classList.add('selected');

  var qrData = encodeURIComponent('QPay|' + gameName + '|' + itemText + '|' + priceText);
  qpayQrImg.src = 'https://api.qrserver.com/v1/create-qr-code/?size=220x220&margin=6&data=' + qrData;

  paymentConfirmBtn.classList.remove('success', 'loading');
  paymentConfirmBtn.disabled = false;
  paymentConfirmBtn.style.width = '';
  paymentConfirmBtn.textContent = 'Төлбөр баталгаажуулах';
  paymentFormView.style.display = '';
  paymentSuccessView.style.display = 'none';
  paymentModalOverlay.classList.add('open');
}

function closePaymentModal(){
  paymentModalOverlay.classList.remove('open');
}

paymentModalClose.addEventListener('click', closePaymentModal);

paymentModalOverlay.addEventListener('click', function(e){
  if(e.target === paymentModalOverlay) closePaymentModal();
});
