/* ==================================================================
   31-payment-data.js — Төлбөр: банкны лого, QPay болон банкны апп-уудын жагсаалт
   ================================================================== */


// ---- Төлбөрийн загвар: QPay QR (доор нь дэмжигдэх банкууд) болон Шилжүүлэг ----
var BANK_LOGOS = {
  'Хаан банк': 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRm04x1xkg2lDXhI0HwzKEUTuCLLUuCTBhpLOITrGlyXw&s=10',
  'Худалдаа хөгжлийн банк': 'https://play-lh.googleusercontent.com/d8ayLze9qciUv6Sx6CJIWYY8l__wKcvNSe1NyoAOc0brf4yoXpgvGxujJVbvsTqHRj2xhxCmUxSZxJfZKIuA'
};

// QPay tab-ийн доор харагдах, дэмжигдэх бүх банкны жагсаалт (зөвхөн мэдээлэл, сонголт биш)
var QPAY_BANKS = [
  { name:'Хаан банк',                 color:'#0a5f38', logo:BANK_LOGOS['Хаан банк'] },
  { name:'Голомт банк',                color:'#1462b0' },
  { name:'Худалдаа хөгжлийн банк',      color:'#7c1f2b', logo:BANK_LOGOS['Худалдаа хөгжлийн банк'] },
  { name:'Төрийн банк',                color:'#0d6e3f' },
  { name:'Хас банк',                   color:'#f5821f' },
  { name:'Ариг банк',                  color:'#5b3aa0' },
  { name:'Богд банк',                  color:'#8a1c2e' },
  { name:'Капитрон банк',              color:'#1f3c88' }
];

// Шилжүүлэг tab-т ашиглах жинхэнэ дансны мэдээлэл
var BANK_APPS = [
  { name:'Хаан банк',                 color:'#0a5f38', account:'5221957701', recipient:'Цэрэндорж Баасанбат', logo:BANK_LOGOS['Хаан банк'] },
  { name:'Худалдаа хөгжлийн банк',     color:'#7c1f2b', account:'445017037',  recipient:'Цэрэндорж Баасанбат', logo:BANK_LOGOS['Худалдаа хөгжлийн банк'] }
];
