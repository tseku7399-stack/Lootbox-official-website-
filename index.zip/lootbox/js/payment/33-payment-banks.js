/* ==================================================================
   33-payment-banks.js — Төлбөр: банк сонгох, дансны мэдээлэл хуулах
   ================================================================== */


function bankInitials(name){
  return name.trim().split(' ').map(function(w){ return w[0]; }).join('').slice(0,2);
}

function bankIconInner(bank){
  return bank.logo
    ? '<img src="' + bank.logo + '" alt="' + bank.name + '" style="width:100%;height:100%;object-fit:contain;border-radius:inherit;">'
    : bankInitials(bank.name);
}

// QPay tab-ийн доор харагдах, дэмжигдэх бүх банкны жагсаалт
qpayBanksRow.innerHTML = QPAY_BANKS.map(function(bank){
  return '<div class="qpay-bank-badge" style="background:' + (bank.logo ? '#fff' : bank.color) + '" title="' + bank.name + '">' + bankIconInner(bank) + '</div>';
}).join('');

// Шилжүүлэг tab-ийн банк сонгох chip-үүд
transferBankChips.innerHTML = BANK_APPS.map(function(bank, i){
  return '<div class="transfer-chip" data-bank-index="' + i + '">' +
      '<div class="transfer-chip-icon" style="background:' + (bank.logo ? '#fff' : bank.color) + '">' + bankIconInner(bank) + '</div>' +
      '<div class="transfer-chip-name">' + bank.name + '</div>' +
    '</div>';
}).join('');

function selectTransferBank(bank, chipEl){
  selectedTransferBank = bank;
  transferBankChips.querySelectorAll('.transfer-chip').forEach(function(c){ c.classList.remove('selected'); });
  if(chipEl) chipEl.classList.add('selected');
  transferBankName.textContent = bank.name;
  transferAccNumber.textContent = bank.account;
  transferRecipient.textContent = bank.recipient;
  transferCopyBtn.classList.remove('copied');
  transferCopyBtn.textContent = 'Хуулах';
}

transferBankChips.querySelectorAll('.transfer-chip').forEach(function(chip){
  chip.addEventListener('click', function(){
    selectTransferBank(BANK_APPS[parseInt(chip.getAttribute('data-bank-index'), 10)], chip);
  });
});

transferCopyBtn.addEventListener('click', function(){
  if(!selectedTransferBank) return;
  var acc = selectedTransferBank.account;
  var done = function(){
    transferCopyBtn.textContent = 'Хуулагдлаа ✓';
    transferCopyBtn.classList.add('copied');
    setTimeout(function(){
      transferCopyBtn.textContent = 'Хуулах';
      transferCopyBtn.classList.remove('copied');
    }, 1500);
  };
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(acc).then(done, function(){ fallbackCopy(acc, done); });
  } else {
    fallbackCopy(acc, done);
  }
});

transferMemoCopyBtn.addEventListener('click', function(){
  if(!currentTransferMemo) return;
  var done = function(){
    transferMemoCopyBtn.textContent = 'Хуулагдлаа ✓';
    transferMemoCopyBtn.classList.add('copied');
    setTimeout(function(){
      transferMemoCopyBtn.textContent = 'Хуулах';
      transferMemoCopyBtn.classList.remove('copied');
    }, 1500);
  };
  if(navigator.clipboard && navigator.clipboard.writeText){
    navigator.clipboard.writeText(currentTransferMemo).then(done, function(){ fallbackCopy(currentTransferMemo, done); });
  } else {
    done();
  }
});
