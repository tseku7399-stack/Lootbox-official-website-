/* ==================================================================
   32-payment-elements.js — Төлбөрийн цонхны HTML элементүүд ба төлөв
   ================================================================== */


var paymentModalOverlay = document.getElementById('paymentModalOverlay');

var paymentModalClose = document.getElementById('paymentModalClose');

var pmGameName = document.getElementById('pmGameName');

var pmItemName = document.getElementById('pmItemName');

var pmAccInfo = document.getElementById('pmAccInfo');

var pmTotalAmount = document.getElementById('pmTotalAmount');

var pmTabQpay = document.getElementById('pmTabQpay');

var pmTabBank = document.getElementById('pmTabBank');

var pmPanelQpay = document.getElementById('pmPanelQpay');

var pmPanelBank = document.getElementById('pmPanelBank');

var qpayQrImg = document.getElementById('qpayQrImg');

var qpayBanksRow = document.getElementById('qpayBanksRow');

var transferBankChips = document.getElementById('transferBankChips');

var transferBankName = document.getElementById('transferBankName');

var transferAccNumber = document.getElementById('transferAccNumber');

var transferRecipient = document.getElementById('transferRecipient');

var transferAmount = document.getElementById('transferAmount');

var transferMemo = document.getElementById('transferMemo');

var transferMemoCopyBtn = document.getElementById('transferMemoCopyBtn');

var transferCopyBtn = document.getElementById('transferCopyBtn');

var currentTransferMemo = '';

var paymentConfirmBtn = document.getElementById('paymentConfirmBtn');

var paymentFormView = document.getElementById('paymentFormView');

var paymentSuccessView = document.getElementById('paymentSuccessView');

var psGameName = document.getElementById('psGameName');

var psAccId = document.getElementById('psAccId');

var psAccName = document.getElementById('psAccName');

var psItemName = document.getElementById('psItemName');

var psAmount = document.getElementById('psAmount');

var psDate = document.getElementById('psDate');

var pendingSelectedPackage = null;

var paymentProcessing = false; // "Төлбөр баталгаажуулах" дарсны дараах loading явж байгаа эсэх

var selectedTransferBank = null;
