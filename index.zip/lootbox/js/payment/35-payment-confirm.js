/* ==================================================================
   35-payment-confirm.js — Төлбөр баталгаажуулах, амжилттай харагдац, түүхэнд хадгалах
   ================================================================== */


paymentConfirmBtn.addEventListener('click', function(){
  if(!pendingSelectedPackage) return;
  playClickSound();
  // Худалдан авалтыг тэмдэглэсний дараа шууд null болгож, loading үзүүлж
  // байх хугацаанд товчийг дахин дарвал (double-tap) худалдан авалт хоёр
  // удаа бичигдэхээс сэргийлнэ.
  var pkg = pendingSelectedPackage;
  pendingSelectedPackage = null;
  paymentProcessing = true;

  // 1) Эхлээд loading (spinner) төлөвийг үзүүлнэ.
  paymentConfirmBtn.classList.remove('success');
  paymentConfirmBtn.classList.add('loading');
  paymentConfirmBtn.disabled = true;
  paymentConfirmBtn.style.width = paymentConfirmBtn.offsetWidth + 'px';
  paymentConfirmBtn.innerHTML = '<span class="btn-spinner"></span>';

  setTimeout(function(){
    // 2) Loading дууссаны дараа дэлгэрэнгүй мэдээлэлтэй амжилтын дэлгэц рүү шилжинэ.
    paymentConfirmBtn.classList.remove('loading');
    paymentConfirmBtn.disabled = false;
    paymentConfirmBtn.style.width = '';
    paymentConfirmBtn.textContent = 'Төлбөр баталгаажуулах';

    var gameName = rechargeTitle.textContent || '';
    var itemText = pkg.getAttribute('data-item') || '';
    var priceText = pkg.getAttribute('data-price') || '';
    var now = new Date();
    var dateStr = now.toLocaleDateString('mn-MN') + ', ' + now.toLocaleTimeString('mn-MN', { hour:'2-digit', minute:'2-digit' });

    var playerIdEl = document.getElementById('playerIdInput');
    var zoneIdEl = document.getElementById('zoneIdInput');
    var idValue = playerIdEl ? playerIdEl.value.trim() : '';
    var zoneValue = zoneIdEl ? zoneIdEl.value.trim() : '';
    var idDisplay = idValue + (zoneValue ? ' (' + zoneValue + ')' : '');
    var accountName = idValue ? generateMockAccount(currentRechargeGame, idValue).name : '—';

    psGameName.textContent = gameName;
    psAccId.textContent = idDisplay || '—';
    psAccName.textContent = accountName;
    psItemName.textContent = itemText;
    psAmount.textContent = priceText;
    psDate.textContent = dateStr;

    paymentFormView.style.display = 'none';
    paymentSuccessView.style.display = 'flex';
    paymentProcessing = false;
    playSuccessSound();
    // Loading явж байх үед цонхыг санамсаргүй хаасан ч "Худалдан авалт амжилттай" дэлгэц заавал гарч ирнэ
    var pmBox = paymentModalOverlay.querySelector('.payment-modal');
    if(pmBox) pmBox.scrollTop = 0;
    paymentModalOverlay.classList.add('open');

    if(currentUser.loggedIn && currentUserKey){
      var users = loadUsers();
      var record = users[currentUserKey];
      if(record){
        if(!record.purchases) record.purchases = [];
        record.purchases.unshift({
          game: gameName,
          accId: idDisplay,
          accName: accountName,
          item: itemText,
          price: priceText,
          date: dateStr,
          status: 'success'
        });
        users[currentUserKey] = record;
        saveUsers(users);
      }
    }

    // ---- Худалдан авалт амжилттай болсны дараа мэдэгдэл нэмнэ (зөвхөн
    // Тохиргоо доторх "Push мэдэгдэл" асаалттай үед). Тухайн мэдэгдэл
    // дээр дарахад яг энэ худалдан авалтын дэлгэрэнгүй мэдээллийг
    // (амжилттай дэлгэц шиг) дахин харуулна. ----
    if(isNotifEnabled()){
      showToast('Цэнэглэлт амжилттай', gameName + ' — ' + itemText + ' амжилттай орлоо.');
      NOTIFICATIONS.unshift({
        icon: 'diamond',
        title: 'Цэнэглэлт амжилттай',
        body: gameName + ' — ' + itemText + ' амжилттай орлоо.',
        time: 'Дөнгөж сая',
        unread: true,
        purchase: {
          game: gameName,
          accId: idDisplay,
          accName: accountName,
          item: itemText,
          price: priceText,
          date: dateStr
        }
      });
      saveNotifications();
      renderNotifications();
    }
  }, 1200);
});
