/* ==================================================================
   38-side-drawer.js — Hamburger цэс (side drawer)
   ================================================================== */


// ---- Hamburger цэс (side drawer): гурван зураас X болж хувирна, зүүнээс гулсаж гарна ----
(function initSideDrawer(){
  var hamburger = document.getElementById('navbarHamburger');
  var overlay = document.getElementById('sideDrawerOverlay');
  var closeBtn = document.getElementById('sideDrawerClose');
  if(!hamburger || !overlay) return;

  function openDrawer(){
    overlay.classList.add('open');
    hamburger.classList.add('active');
  }
  function closeDrawer(){
    overlay.classList.remove('open');
    hamburger.classList.remove('active');
  }
  function toggleDrawer(){
    if(overlay.classList.contains('open')) closeDrawer(); else openDrawer();
  }

  hamburger.addEventListener('click', function(e){
    e.stopPropagation();
    toggleDrawer();
  });
  closeBtn.addEventListener('click', closeDrawer);
  overlay.addEventListener('click', function(e){
    if(e.target === overlay) closeDrawer();
  });

  var homeLink = document.getElementById('drawerHomeLink');
  if(homeLink){
    homeLink.addEventListener('click', function(){
      closeDrawer();
      document.getElementById('allGamesView').style.display = 'none';
      document.getElementById('mainView').style.display = 'block';
    });
  }
  var allGamesLink = document.getElementById('drawerAllGamesLink');
  if(allGamesLink){
    allGamesLink.addEventListener('click', function(){
      closeDrawer();
      document.getElementById('mainView').style.display = 'none';
      document.getElementById('allGamesView').style.display = 'block';
    });
  }
  var profileLink = document.getElementById('drawerProfileLink');
  if(profileLink){
    profileLink.addEventListener('click', function(){
      closeDrawer();
      if(typeof handleOpenProfileClick === 'function') handleOpenProfileClick();
    });
  }
  var historyLink = document.getElementById('drawerHistoryLink');
  if(historyLink){
    historyLink.addEventListener('click', function(){
      closeDrawer();
      if(typeof handleOpenProfileClick === 'function') handleOpenProfileClick();
    });
  }
  var notifLink = document.getElementById('drawerNotifLink');
  if(notifLink){
    notifLink.addEventListener('click', function(){
      closeDrawer();
      var bell = document.getElementById('notifBell');
      if(bell) bell.click();
    });
  }
  var settingsLink = document.getElementById('drawerSettingsLink');
  if(settingsLink){
    settingsLink.addEventListener('click', function(){
      closeDrawer();
      var settingsOverlay = document.getElementById('settingsModalOverlay');
      if(settingsOverlay) settingsOverlay.classList.add('open');
    });
  }
  var profileSettingsBtn = document.getElementById('profileSettingsBtn');
  if(profileSettingsBtn){
    profileSettingsBtn.addEventListener('click', function(){
      var settingsOverlay = document.getElementById('settingsModalOverlay');
      if(settingsOverlay) settingsOverlay.classList.add('open');
    });
  }
  var logoutLink = document.getElementById('drawerLogoutLink');
  if(logoutLink){
    logoutLink.addEventListener('click', function(){
      closeDrawer();
      var authBtn = document.getElementById('profileAuthBtn');
      if(authBtn) authBtn.click();
    });
  }
})();
