/* ==================================================================
   05-topbar.js — Дээд хэсгийн хэрэглэгчийн нэр / avatar-ыг зурах
   ================================================================== */


function getInitials(name){
  var parts = name.trim().split(/\s+/).filter(Boolean);
  if(parts.length === 0) return '??';
  if(parts.length === 1) return parts[0].slice(0,2).toUpperCase();
  return (parts[0][0] + parts[1][0]).toUpperCase();
}

function renderTopbar(){
  var navAvatarEl = document.getElementById('navbarAvatar');
  if(!navAvatarEl) return;
  navAvatarEl.innerHTML = '';
  if(currentUser.avatarImg){
    var img = document.createElement('img');
    img.src = currentUser.avatarImg;
    img.style.cssText = 'width:100%;height:100%;object-fit:cover;border-radius:50%;';
    navAvatarEl.appendChild(img);
  } else if(currentUser.loggedIn){
    navAvatarEl.textContent = currentUser.avatarText;
  } else {
    navAvatarEl.innerHTML = '<svg viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="8" r="4"/><path d="M4 20c0-4 3.5-7 8-7s8 3 8 7"/></svg>';
  }
}

renderTopbar();
