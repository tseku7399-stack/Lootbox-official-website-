/* ==================================================================
   08-toast.js — Амжилттай мессеж (toast): 3 сек-ийн дараа алга болно, дээш гулсуулж арилгана
   ================================================================== */


// ---- Амжилттай мессеж (toast): 3 секундын дараа өөрөө алга болно, гараар дээш гулсуулж арилгаж болно ----
var appToast = document.getElementById('appToast');

var appToastTitle = document.getElementById('appToastTitle');

var appToastText = document.getElementById('appToastText');

var appToastTimer = null;

var appToastDrag = null;

var APP_TOAST_MS = 3000;

function resetToastInline(){
  appToast.style.transform = '';
  appToast.style.opacity = '';
  appToast.classList.remove('dragging');
}

function hideToast(){
  clearTimeout(appToastTimer);
  appToastDrag = null;
  appToast.classList.remove('show');
  appToast.style.display = 'none';
  resetToastInline();
}

function startToastTimer(){
  clearTimeout(appToastTimer);
  appToastTimer = setTimeout(function(){
    appToast.classList.remove('show');
    appToastTimer = setTimeout(hideToast, 300);
  }, APP_TOAST_MS);
}

function showToast(title, text){
  clearTimeout(appToastTimer);
  appToastDrag = null;
  resetToastInline();
  appToastTitle.textContent = title || '';
  appToastText.textContent = text || '';
  appToastText.style.display = text ? 'block' : 'none';
  appToast.style.display = 'flex';
  void appToast.offsetWidth;
  appToast.classList.add('show');
  startToastTimer();
}

appToast.addEventListener('pointerdown', function(e){
  if(!appToast.classList.contains('show')) return;
  clearTimeout(appToastTimer);
  appToastDrag = { y: e.clientY, dy: 0 };
  appToast.classList.add('dragging');
  try{ appToast.setPointerCapture(e.pointerId); }catch(err){}
});

appToast.addEventListener('pointermove', function(e){
  if(!appToastDrag) return;
  appToastDrag.dy = Math.min(0, e.clientY - appToastDrag.y); // зөвхөн дээш татна, хажуу тийш хөдлөхгүй
  appToast.style.transform = 'translate(-50%, ' + appToastDrag.dy + 'px)';
  appToast.style.opacity = String(Math.max(0.25, 1 - Math.abs(appToastDrag.dy) / 90));
});

function endToastDrag(){
  if(!appToastDrag) return;
  var dy = appToastDrag.dy;
  appToastDrag = null;
  appToast.classList.remove('dragging');
  if(dy < -30){
    // Хангалттай дээш гулсуулсан: дээшээ нисээд алга болно
    appToast.style.transform = 'translate(-50%, -120px)';
    appToast.style.opacity = '0';
    clearTimeout(appToastTimer);
    appToastTimer = setTimeout(hideToast, 220);
  } else {
    // Хүрэлцэхгүй бол байранд нь буцаж, 3 секундын тоолол дахин эхэлнэ
    resetToastInline();
    startToastTimer();
  }
}

appToast.addEventListener('pointerup', endToastDrag);

appToast.addEventListener('pointercancel', endToastDrag);
