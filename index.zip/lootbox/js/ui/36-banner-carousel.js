/* ==================================================================
   36-banner-carousel.js — Нүүр хуудасны banner: хоёр тийш swipe хийдэг, төгсгөлгүй эргэлддэг
   ================================================================== */


// ---- Banner: гараар хоёр тийш чөлөөтэй swipe хийж, төгсгөлгүй эргэлддэг (infinite loop) болгох ----
(function initBannerCarousel(){
  var bannerEl = document.getElementById('balanceBanner');
  var trackEl = document.getElementById('balanceBannerTrack');
  var dotsEl = document.getElementById('balanceDots');
  if(!bannerEl || !trackEl || !dotsEl) return;

  var originalSlides = Array.prototype.slice.call(trackEl.children);
  var N = originalSlides.length;
  if(N === 0) return;

  // Хоёр талд нь эхний/сүүлийн зургийн хуулбарыг тавьж, ямар ч чиглэлд
  // чирэхэд яг мэдрэгдэхгүйгээр (seamless) эргэлддэг болгоно.
  var lastClone = originalSlides[N - 1].cloneNode(true);
  var firstClone = originalSlides[0].cloneNode(true);
  lastClone.setAttribute('aria-hidden', 'true');
  firstClone.setAttribute('aria-hidden', 'true');
  trackEl.insertBefore(lastClone, originalSlides[0]);
  trackEl.appendChild(firstClone);

  var dots = dotsEl.querySelectorAll('.dot');
  var currentIndex = 1; // 0 = clone(сүүлийн), 1..N = жинхэнэ зургууд, N+1 = clone(эхний)
  var containerWidth = 0;
  var isDragging = false;
  var dragStartX = 0;
  var dragDeltaX = 0;
  var autoTimer = null;
  var pointerId = null;

  function getContainerWidth(){
    return bannerEl.getBoundingClientRect().width;
  }

  // Track болон түүний бүх slide (clone-уудыг оролцуулаад)-д нь px-ээр
  // өргөн тохируулж өгнө. Үгүй бол track өөрийн хайрцаг (box) нь зөвхөн
  // нэг slide-ийн өргөнтэй тэнцүү үлдэж, transform-оор шилжсэний дараа
  // харагдаж буй зурган дээр гар/хулгана дарахад pointer event track
  // элемент рүү бариагдахгүй өнгөрчихдөг байсан тул chirэх (drag) ажиллахгүй байв.
  function applySizes(){
    containerWidth = getContainerWidth();
    var totalSlides = trackEl.children.length;
    trackEl.style.width = (totalSlides * containerWidth) + 'px';
    Array.prototype.forEach.call(trackEl.children, function(child){
      child.style.flex = '0 0 ' + containerWidth + 'px';
      child.style.width = containerWidth + 'px';
    });
  }

  // Автомат солигдол: удаан, зөөлөн эхэлж зөөлөн зогсох (ease-in-out) 1.1 секунд.
  // Гараар swipe хийсний дараах шилжилт: хурууны хөдөлгөөнийг үргэлжлүүлсэн
  // мэт зөөлөн саарах 0.7 секунд. (Автомат солигдох 4 секундын давтамж хэвээр.)
  var AUTO_TRANSITION = 'transform 1.1s cubic-bezier(0.65, 0, 0.35, 1)';
  var SWIPE_TRANSITION = 'transform 0.7s cubic-bezier(0.22, 0.61, 0.36, 1)';
  var nextTransition = AUTO_TRANSITION;

  function setPosition(withTransition){
    trackEl.style.transition = withTransition ? nextTransition : 'none';
    var offset = -(currentIndex * containerWidth) + dragDeltaX;
    trackEl.style.transform = 'translateX(' + offset + 'px)';
  }

  function updateDots(){
    var realIndex = ((currentIndex - 1) % N + N) % N;
    dots.forEach(function(d, i){
      d.classList.toggle('active', i === realIndex);
    });
  }

  function stopAutoTimer(){
    clearInterval(autoTimer);
    autoTimer = null;
  }

  // Track-ийн chirэгддэг байрлал бодитоор зөвхөн 0..N+1 хооронд байдаг
  // ч clone дээр (0 буюу N+1) ирээд, transitionend хараахан
  // "жинхэнэ" слайд руу нь буцаагаагүй байхад дараагийн chirэлт (+1/-1)
  // тооцоологдвол шууд хязгаараас гадагш гарчихдаг. Иймд шинэ шилжилт
  // тооцоолохын өмнө currentIndex-г үргэлж (clone дээр байсан ч,
  // хэдийнэ хэт хол гарсан ч) тухайн бодит слайд руугаа (1..N)
  // анимацгүйгээр эргүүлж тохируулна.
  function normalizeIndex(){
    var real = ((currentIndex - 1) % N + N) % N + 1;
    if(real !== currentIndex){
      currentIndex = real;
      setPosition(false);
    }
  }

  // Автомат солигдол 4 секунд тутам явж байх бөгөөд, гараар хөдөлгөх
  // бүрд энэ таймер шинээр эхэлж, дараагийн автомат солигдол 4 секундын
  // дараа л болно. Тохиргоо доторх "Нүүр хуудасны видео тоглуулах"
  // унтраалттай үед автоматаар огт эргэлдэхгүй (гараар л шилжинэ).
  function restartAutoTimer(){
    stopAutoTimer();
    if(!isAutoplayEnabled()) return;
    autoTimer = setInterval(function(){
      normalizeIndex();
      nextTransition = AUTO_TRANSITION;
      goToIndex(currentIndex + 1);
    }, 4000);
  }

  // Тохиргооны цонхны "Нүүр хуудасны видео тоглуулах" товч энэ баннерыг
  // тэр даруйд нь асаах/унтраах боломжтой байхаар, удирдлагыг нь
  // дэлхийн (window) түвшинд гаргаж өгнө.
  window.__bannerAutoplayControl = {
    start: restartAutoTimer,
    stop: stopAutoTimer
  };

  function goToIndex(newIndex){
    currentIndex = newIndex;
    dragDeltaX = 0;
    setPosition(true);
    updateDots();
  }

  // Clone зураг дээр ирж зогссоны дараа, transition дуусмагц анимацгүйгээр
  // яг тухайн жинхэнэ зураг дээр "үсрэн" очиж, төгсгөлгүй мэт мэдрэгддэг болгоно.
  trackEl.addEventListener('transitionend', function(e){
    if(e.propertyName && e.propertyName !== 'transform') return;
    if(currentIndex === 0){
      currentIndex = N;
      setPosition(false);
    } else if(currentIndex === N + 1){
      currentIndex = 1;
      setPosition(false);
    }
  });

  // Slide шилжиж байх үед хуруугаараа барьвал байрлал нь "үсрэхгүй", яг одоо
  // харагдаж буй цэгээсээ зогсоод хуруунд нь дагана.
  function getVisualX(){
    var tr = window.getComputedStyle(trackEl).transform;
    if(!tr || tr === 'none') return null;
    var m = tr.match(/matrix\(([^)]+)\)/);
    if(!m) return null;
    var v = parseFloat(m[1].split(',')[4]);
    return isNaN(v) ? null : v;
  }

  var dragBase = 0;

  function onPointerDown(e){
    containerWidth = getContainerWidth();
    var vx = getVisualX();
    var oldIndex = currentIndex;
    normalizeIndex();
    dragBase = 0;
    if(vx !== null){
      // normalizeIndex clone -> жинхэнэ слайд руу N слайдаар шилжүүлсэн бол харагдах
      // байрлалыг мөн адил шилжүүлж, зураг үсрэхгүй байлгана
      var vxNorm = vx - (currentIndex - oldIndex) * containerWidth;
      dragBase = vxNorm + currentIndex * containerWidth;
      if(Math.abs(dragBase) > containerWidth) dragBase = 0;
    }
    isDragging = true;
    pointerId = e.pointerId;
    dragStartX = e.clientX;
    dragDeltaX = dragBase;
    trackEl.classList.add('dragging');
    stopAutoTimer();
    setPosition(false);
    try{ trackEl.setPointerCapture(pointerId); }catch(err){}
  }

  function onPointerMove(e){
    if(!isDragging) return;
    dragDeltaX = dragBase + (e.clientX - dragStartX);
    setPosition(false);
  }

  function onPointerUp(e){
    if(!isDragging) return;
    isDragging = false;
    trackEl.classList.remove('dragging');
    var threshold = containerWidth * 0.08;
    normalizeIndex();
    nextTransition = SWIPE_TRANSITION;
    // Чиглэлийг хурууны бодит хөдөлгөөнөөр (барьсан цэгээсээ хойш) тодорхойлно: чирээгүй
    // бол явж байсан чиглэлээрээ дараагийн зураг руу зөөлөн үргэлжилнэ
    var moved = dragDeltaX - dragBase;
    if(moved <= -threshold){
      goToIndex(currentIndex + 1);
    } else if(moved >= threshold){
      goToIndex(currentIndex - 1);
    } else {
      dragDeltaX = 0;
      setPosition(true);
    }
    try{ trackEl.releasePointerCapture(pointerId); }catch(err){}
    restartAutoTimer();
  }

  trackEl.addEventListener('pointerdown', onPointerDown);
  trackEl.addEventListener('pointermove', onPointerMove);
  trackEl.addEventListener('pointerup', onPointerUp);
  trackEl.addEventListener('pointercancel', onPointerUp);

  // Cache: mainView (эсвэл дурын эцэг элемент) display:none үед
  // getBoundingClientRect() 0 буцаадаг тул тэр үед хэмжээг дахин
  // тооцоолохгүй, зөвхөн бодит (0-ээс их) өргөн ирсэн үед л шинэчилнэ.
  // Ингэснээр login/profile гэх мэт дэлгэц рүү орж (жишээ нь гар
  // бичвэрийн keyboard нээгдэхэд resize event гарна) гарч ирэхэд
  // banner "алга" болохгүй.
  window.addEventListener('resize', function(){
    var w = getContainerWidth();
    if(w <= 0) return;
    applySizes();
    setPosition(false);
  });

  // mainView дахин харагдах мөч бүрд (display:none -> block) banner-ийн
  // бодит хэмжээг ResizeObserver ашиглан автоматаар дахин тооцоолж,
  // дурын навигацийн газраас буцаж ирэхэд ч banner үргэлж зөв харагдана.
  if(typeof ResizeObserver !== 'undefined'){
    var lastObservedWidth = 0;
    var ro = new ResizeObserver(function(){
      var w = getContainerWidth();
      if(w > 0 && Math.round(w) !== Math.round(lastObservedWidth)){
        lastObservedWidth = w;
        applySizes();
        setPosition(false);
      }
    });
    ro.observe(bannerEl);
  }

  applySizes();
  setPosition(false);
  updateDots();
  restartAutoTimer();
})();
