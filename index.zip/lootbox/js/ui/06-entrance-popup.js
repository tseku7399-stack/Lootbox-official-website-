/* ==================================================================
   06-entrance-popup.js — Сайтад ормогц гарч ирэх popup
   ================================================================== */


// ---- Сайтад ормогц гарч ирэх popup ----
(function initEntrancePopup(){
  var overlay = document.getElementById('entrancePopupOverlay');
  var closeBtn = document.getElementById('entrancePopupClose');
  if(!overlay || !closeBtn) return;
  overlay.style.display = 'flex';
  function closePopup(){
    overlay.style.display = 'none';
  }
  closeBtn.addEventListener('click', closePopup);
  overlay.addEventListener('click', function(e){
    if(e.target === overlay) closePopup();
  });
})();
