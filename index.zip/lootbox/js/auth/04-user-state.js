/* ==================================================================
   04-user-state.js — Одоогийн хэрэглэгчийн төлөв (currentUser) ба локал профайлын бүртгэл
   ================================================================== */


// ---- Хэрэглэгчийн төлөв ----
// Бүртгүүлээгүй, нэвтрээгүй байсан ч сайтад "Зочин"-оор шууд орж болно.
var currentUser = {
  username: 'Зочин',
  avatarText: 'ЗЧ',
  avatarImg: null,
  email: '',
  loggedIn: false
};

var currentUserKey = null; // Firebase хэрэглэгчийн uid (локал профайл сан дахь түлхүүр)

// ---- Firebase хэрэглэгчийн обьект/OAuth үр дүнгээс имэйлийг хамгийн
// найдвартай эх сурвалжаас олж авах. user.email заримдаа хоосон гарч ирдэг
// тул providerData болон OAuth-ийн profile мэдээллээс нөөц эх сурвалж хайна.
function pickEmail(user, result){
  if(user && user.email) return user.email;
  if(user && user.providerData){
    for(var i=0;i<user.providerData.length;i++){
      if(user.providerData[i] && user.providerData[i].email) return user.providerData[i].email;
    }
  }
  if(result && result.additionalUserInfo && result.additionalUserInfo.profile && result.additionalUserInfo.profile.email){
    return result.additionalUserInfo.profile.email;
  }
  return '';
}

// ---- Google-ээр анх удаа нэвтрэхэд Google-ийн (эсвэл имэйлээс гаргаж
// авсан) нэр өөр хэрэглэгчийн username-тэй давхцаж болзошгүй тул (жишээ
// нь ижил нэртэй хоёр өөр хүн Google-ээр нэвтрэх) username хаана ч
// давхцахгүй байхын тулд шаардлагатай бол "Нэр2", "Нэр3" гэх мэт
// дугаар залгаж цор ганц болгоно. ----
function makeUniqueUsername(baseName){
  var base = (baseName || 'Хэрэглэгч').trim() || 'Хэрэглэгч';
  if(!isUsernameTaken(base)) return base;
  var n = 2;
  while(isUsernameTaken(base + n)){ n++; }
  return base + n;
}

// ---- Firebase хэрэглэгчийг локал профайл (avatar/purchases г.м) руу тааруулж, currentUser-ийг шинэчлэх ----
function getOrCreateLocalRecord(user, result){
  var users = loadUsers();
  var key = user.uid;
  var record = users[key];
  var bestEmail = pickEmail(user, result);
  if(!record){
    var baseName = user.displayName || (bestEmail ? bestEmail.split('@')[0] : 'Хэрэглэгч');
    record = {
      displayName: makeUniqueUsername(baseName),
      email: bestEmail || '',
      avatarImg: user.photoURL || null,
      provider: (user.providerData && user.providerData[0] && user.providerData[0].providerId) || 'password',
      purchases: []
    };
    users[key] = record;
    saveUsers(users);
  } else if(bestEmail && record.email !== bestEmail){
    record.email = bestEmail;
    users[key] = record;
    saveUsers(users);
  }
  return { key: key, record: record };
}

function applyUserRecord(key, record){
  currentUserKey = key;
  currentUser.username = record.displayName;
  currentUser.avatarText = getInitials(record.displayName);
  currentUser.avatarImg = record.avatarImg || null;
  // Firebase-ийн бодит нэвтэрсэн хэрэглэгчийн имэйлийг үнэн зөв эх сурвалж
  // болгож, локал бичлэг дэх (хуучирсан/дутуу байж болзошгүй) имэйлээс
  // ЯМАГТ илүү дээгүүр тавина. Ингэснээр Google-ээр нэвтрэх/бүртгүүлэх
  // үед ч тухайн жинхэнэ gmail хаяг профайлд яг зөв харагдана.
  var liveEmail = '';
  try{
    liveEmail = pickEmail(firebase.auth().currentUser);
  }catch(e){}
  currentUser.email = liveEmail || record.email || '';
  // Локал бичлэг Firebase-ийн бодит имэйлтэй зөрж байвал (хоосон эсвэл
  // өөр байвал) нэн даруй сэргээж, дараагийн удаа дахин алдахгүй байхаар хадгална.
  if(liveEmail && record.email !== liveEmail && key){
    var usersToFix = loadUsers();
    if(usersToFix[key]){
      usersToFix[key].email = liveEmail;
      saveUsers(usersToFix);
    }
  }
  currentUser.loggedIn = true;
  renderTopbar();
}
