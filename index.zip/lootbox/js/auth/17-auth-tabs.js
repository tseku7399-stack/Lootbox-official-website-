/* ==================================================================
   17-auth-tabs.js — Нэвтрэх / Бүртгүүлэх табууд ба холбоосууд
   ================================================================== */


tabLogin.addEventListener('click', function(){ showAuthPanel('login'); });

tabRegister.addEventListener('click', function(){ hideToast(); showAuthPanel('register'); });

forgotLink.addEventListener('click', function(){ showAuthPanel('forgot'); });

backToLoginLink.addEventListener('click', function(){ showAuthPanel('login'); });
