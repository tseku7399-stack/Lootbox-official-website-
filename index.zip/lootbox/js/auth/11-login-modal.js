/* ==================================================================
   11-login-modal.js — Нэвтрэх дэлгэцийг нээх / хаах
   ================================================================== */


function openLogin(returnTo){
  loginReturnTo = returnTo || 'main';
  loginOpenedFrom = getCurrentVisiblePage();
  showAllPagesHidden();
  loginUsername.value = '';
  loginPassword.value = '';
  loginError.style.display = 'none';
  clearFieldError(loginUsernameError);
  clearFieldError(loginPasswordError);
  hideToast();
  registerUsername.value = '';
  registerEmail.value = '';
  registerPassword.value = '';
  registerPassword2.value = '';
  registerError.style.display = 'none';
  clearFieldError(registerUsernameError);
  clearFieldError(registerEmailError);
  clearFieldError(registerPasswordError);
  clearFieldError(registerPassword2Error);
  forgotInput.value = '';
  forgotError.style.display = 'none';
  forgotSent.style.display = 'none';
  showAuthPanel('login');
  loginView.style.display = 'block';
  updateInAppBrowserNotice();
}

function closeLogin(){
  loginView.style.display = 'none';
  if(loginOpenedFrom){
    loginOpenedFrom.style.display = 'block';
  } else {
    document.getElementById('mainView').style.display = 'block';
  }
}

loginCloseBtn.addEventListener('click', closeLogin);
