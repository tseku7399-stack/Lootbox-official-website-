/* ==================================================================
   12-form-helpers.js — Формын нийтлэг туслахууд: алдааны мессеж, талбар улайлгах, товчны spinner
   ================================================================== */


function setLoginError(msg){
  loginError.textContent = msg;
  loginError.style.display = 'block';
}

function setRegisterError(msg){
  registerError.textContent = msg;
  registerError.style.display = 'block';
}

// ---- Тухайн талбарынхаа яг доор нь харагдах сануулга (field-error) ----
function setFieldError(el, msg){
  if(!el) return;
  el.textContent = msg;
  el.style.display = 'block';
}

function clearFieldError(el){
  if(!el) return;
  el.style.display = 'none';
  el.textContent = '';
}

// ---- Буруу бөглөсөн талбар руу шилжиж, улайлган анхааруулах ----
// errorEl дамжуулбал тухайн input дахин бичигдэх мөчид харгалзах сануулга
// мессежийг ч мөн автоматаар нуух болно.
function highlightInvalidField(input, errorEl){
  if(!input) return;
  input.classList.add('field-invalid');
  input.scrollIntoView({ behavior:'smooth', block:'center' });
  input.focus();
  clearTimeout(input._fieldInvalidTimer);
  input._fieldInvalidTimer = setTimeout(function(){
    input.classList.remove('field-invalid');
  }, 2200);
  input._currentFieldError = errorEl || null;
  if(!input._fieldInvalidBound){
    input._fieldInvalidBound = true;
    input.addEventListener('input', function(){
      input.classList.remove('field-invalid');
      if(input._currentFieldError){
        clearFieldError(input._currentFieldError);
      }
    });
  }
}

// ---- Input биш хэсэг (жишээ нь багц сонгох grid) рүү шилжиж анхааруулах ----
function highlightInvalidSection(el){
  if(!el) return;
  el.classList.add('section-invalid');
  el.scrollIntoView({ behavior:'smooth', block:'center' });
  clearTimeout(el._sectionInvalidTimer);
  el._sectionInvalidTimer = setTimeout(function(){
    el.classList.remove('section-invalid');
  }, 2200);
}

// key: users обьект дахь түлхүүр, record: {password, displayName, avatarImg, provider}
function completeAuth(key, record){
  applyUserRecord(key, record);
  loginView.style.display = 'none';
  if(loginReturnTo === 'profile'){
    openProfile();
  } else if(loginReturnTo === 'recharge'){
    rechargeView.style.display = 'block';
  } else {
    document.getElementById('mainView').style.display = 'block';
  }
  showToast('Амжилттай нэвтэрлээ', 'Тавтай морил, ' + currentUser.username + '!');
}

// ---- Товч дээрх "Түр хүлээнэ үү..." бичгийн оронд spinner (loading) харуулна ----
function setBtnLoading(btn){
  btn.style.height = btn.offsetHeight + 'px'; // spinner-ээр солигдоход товчийн өндөр өөрчлөгдөхгүй
  btn.classList.add('loading');
  btn.disabled = true;
  btn.innerHTML = '<span class="btn-spinner"></span>';
}

function resetBtn(btn, label){
  btn.classList.remove('loading');
  btn.style.height = '';
  btn.disabled = false;
  btn.textContent = label;
}
