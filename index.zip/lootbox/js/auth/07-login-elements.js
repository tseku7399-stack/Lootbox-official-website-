/* ==================================================================
   07-login-elements.js — Нэвтрэх / Бүртгүүлэх / Нууц үг мартсан хэсгийн HTML элементүүд
   ================================================================== */


// ---- Нэвтрэх / Бүртгүүлэх / Нууц үг мартах ----
var loginView = document.getElementById('loginView');

var loginUsername = document.getElementById('loginUsername');

var loginPassword = document.getElementById('loginPassword');

var loginError = document.getElementById('loginError');

var loginUsernameError = document.getElementById('loginUsernameError');

var loginPasswordError = document.getElementById('loginPasswordError');

var loginBtn = document.getElementById('loginBtn');

var loginReturnTo = 'main'; // 'main' эсвэл 'profile' - нэвтэрсний дараа хаашаа буцахыг заана

var tabLogin = document.getElementById('tabLogin');

var tabRegister = document.getElementById('tabRegister');

var loginPanel = document.getElementById('loginPanel');

var registerPanel = document.getElementById('registerPanel');

var forgotPanel = document.getElementById('forgotPanel');

var forgotLink = document.getElementById('forgotLink');

var backToLoginLink = document.getElementById('backToLoginLink');

var registerUsername = document.getElementById('registerUsername');

var registerUsernameError = document.getElementById('registerUsernameError');

var registerEmail = document.getElementById('registerEmail');

var registerEmailError = document.getElementById('registerEmailError');

var registerPassword = document.getElementById('registerPassword');

var registerPasswordError = document.getElementById('registerPasswordError');

var registerPassword2 = document.getElementById('registerPassword2');

var registerPassword2Error = document.getElementById('registerPassword2Error');

var registerError = document.getElementById('registerError');

var registerBtn = document.getElementById('registerBtn');

var forgotInput = document.getElementById('forgotInput');

var forgotError = document.getElementById('forgotError');

var forgotSent = document.getElementById('forgotSent');

var forgotBtn = document.getElementById('forgotBtn');

var googleLoginBtn = document.getElementById('googleLoginBtn');

var googleRegisterBtn = document.getElementById('googleRegisterBtn');

var loginCloseBtn = document.getElementById('loginCloseBtn');

var inAppBrowserNotice = document.getElementById('inAppBrowserNotice');

var inAppBrowserNoticeText = document.getElementById('inAppBrowserNoticeText');

var iabnCopyBtn = document.getElementById('iabnCopyBtn');

var loginOpenedFrom = null;
