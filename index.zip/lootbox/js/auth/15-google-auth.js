/* ==================================================================
   15-google-auth.js — Google-ээр нэвтрэх / бүртгүүлэх
   ================================================================== */


// ---- Google-ээр нэвтрэх / бүртгүүлэх: Firebase-ийн жинхэнэ Google OAuth popup ашиглана ----
// googleAuthInProgress хамгаалалт: попап нээгдэж байх зуур товчийг дахин
// дарахад Firebase "auth/cancelled-popup-request" алдаа шиднэ (хуучин
// хүсэлт цуцлагдана). Товчийг түр идэвхгүй болгосноор энэ алдаа гарахгүй
// бөгөөд хэрэглэгчид ачаалж буйг нь мэдэгдэнэ (илүү хурдан мэт мэдрэгдэнэ).
var googleAuthInProgress = false;

var googleAuthTimeoutId = null;

// Товчийг дахин ажиллагаанд оруулах цорын ганц газар (хаанаас ч дуудаж болно)
function resetGoogleButtons(){
  googleAuthInProgress = false;
  if(googleAuthTimeoutId){ clearTimeout(googleAuthTimeoutId); googleAuthTimeoutId = null; }
  if(googleLoginBtn) googleLoginBtn.disabled = false;
  if(googleRegisterBtn) googleRegisterBtn.disabled = false;
}

// Mobile дээр Google account сонгох цонх руу шилжээд буцаад гарахад
// заримдаа Firebase-ийн promise хэзээ ч resolve/reject хийгдэлгүй
// "зогсчихдог" тул товч мөнхөд харлаад (disabled) үлддэг байсан.
// Хуудас дахин харагдмагц (буцаж ирмэгц) бага зэрэг хүлээгээд хариу
// ирээгүй л байвал товчийг хүчээр сэргээнэ.
document.addEventListener('visibilitychange', function(){
  if(document.visibilityState === 'visible' && googleAuthInProgress){
    setTimeout(function(){
      if(googleAuthInProgress) resetGoogleButtons();
    }, 1200);
  }
});

function doGoogleAuth(){
  if(googleAuthInProgress) return;
  var inAppName = detectInAppBrowser();
  if(inAppName){
    var msg = inAppBrowserMessage(inAppName);
    if(registerPanel.style.display !== 'none'){ setRegisterError(msg); } else { setLoginError(msg); }
    return;
  }
  googleAuthInProgress = true;
  if(googleLoginBtn) googleLoginBtn.disabled = true;
  if(googleRegisterBtn) googleRegisterBtn.disabled = true;
  var provider = new firebase.auth.GoogleAuthProvider();
  // Имэйл хаягийг Google-ээс баталгаатай авахын тулд шаардлагатай scope-уудыг тодорхой хүснэ.
  provider.addScope('email');
  provider.addScope('profile');
  // prompt:'select_account' байхгүй бол хэрэглэгчийн броузерт аль хэдийн
  // нэвтэрсэн Google сесс байвал Google account сонгох дэлгэц огт
  // харуулахгүй, шууд тухайн сессийн бүртгэлээр нэвтрүүлдэг. Энэ
  // custom parameter-ийг зааж өгснөөр товч дарах бүрд account chooser
  // ЯМАГТ гарч, хэрэглэгч бүртгэлээ сонгох боломжтой болно.
  provider.setCustomParameters({ prompt: 'select_account' });
  // Нөөц хамгаалалт: ямар ч шалтгаанаар Firebase-ийн хариу 25 секундэд
  // ирэхгүй бол товчийг хүчээр идэвхжүүлж, хэрэглэгчийг мөнхөд
  // түгжигдэхээс сэргийлнэ.
  googleAuthTimeoutId = setTimeout(resetGoogleButtons, 25000);
  firebase.auth().signInWithPopup(provider)
    .then(function(result){
      var kr = getOrCreateLocalRecord(result.user, result);
      completeAuth(kr.key, kr.record);
    })
    .catch(function(err){
      var code = err && err.code;
      // Хэрэглэгч өөрөө Google цонхыг хааж цуцалсан бол энэ бодит алдаа
      // биш тул ямар ч анхааруулга/мессеж бүү харуул — товчийг л дуулгавартай сэргээгээд болино.
      if(code === 'auth/popup-closed-by-user' || code === 'auth/cancelled-popup-request' || code === 'auth/user-cancelled'){
        return;
      }
      var msg = firebaseErrorMessage(err);
      if(registerPanel.style.display !== 'none'){
        setRegisterError(msg);
      } else {
        setLoginError(msg);
      }
    })
    .finally(function(){
      resetGoogleButtons();
    });
}

if(googleLoginBtn) googleLoginBtn.addEventListener('click', doGoogleAuth);

if(googleRegisterBtn) googleRegisterBtn.addEventListener('click', doGoogleAuth);
