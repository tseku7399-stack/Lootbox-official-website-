/* ==================================================================
   03-firebase-errors.js — Firebase алдааг монгол мессеж болгон хөрвүүлэх
   ================================================================== */


function firebaseErrorMessage(err){
  var code = err && err.code;
  var map = {
    'auth/invalid-email': 'Зөв имэйл хаяг оруулна уу',
    'auth/user-not-found': 'Ийм имэйлээр бүртгэл олдсонгүй',
    'auth/wrong-password': 'Нууц үг буруу байна',
    'auth/invalid-credential': 'Имэйл эсвэл нууц үг буруу байна',
    'auth/email-already-in-use': 'Энэ имэйл хаягаар өмнө нь бүртгүүлсэн байна',
    'auth/weak-password': 'Нууц үг дор хаяж 6 тэмдэгт байх ёстой',
    'auth/network-request-failed': 'Сүлжээний алдаа гарлаа. Дахин оролдоно уу',
    'auth/too-many-requests': 'Хэт олон оролдлого хийсэн тул түр хүлээнэ үү',
    // Facebook/Messenger/Instagram зэрэг апп-н дотоод (in-app) browser-үүдэд
    // Google өөрөө OAuth нэвтрэлтийг блоклодог тул popup нээгдэхгүй эсвэл
    // "энэ орчинд дэмжигдэхгүй" гэсэн доорх алдаанууд шидэгддэг.
    'auth/operation-not-supported-in-this-environment': 'Google энд ажиллахгүй. Chrome/Safari-д нээгээрэй',
    'auth/popup-blocked': 'Google цонх нээгдсэнгүй. Chrome/Safari-д нээгээрэй',
    'auth/web-storage-unsupported': 'Энэ browser дэмжигдэхгүй. Chrome/Safari-д нээгээрэй',
    'auth/unauthorized-domain': 'Энэ хаяг зөвшөөрөгдөөгүй байна'
  };
  return (code && map[code]) || (err && err.message) || 'Алдаа гарлаа. Дахин оролдоно уу';
}
