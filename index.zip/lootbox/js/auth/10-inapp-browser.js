/* ==================================================================
   10-inapp-browser.js — Facebook/Messenger/Instagram доторх browser-ийг илрүүлж анхааруулах
   ================================================================== */


// ---- Facebook/Messenger/Instagram зэрэг апп-н дотоод browser дотор
// нээгдсэн бол Google-ээр нэвтрэх товч дарагдахаас өмнө нь Нэвтрэх цонх
// нээгдэх дор дороо анхааруулга харуулна (зөвхөн товч дарсны дараа
// алдаа харуулахаас илүү, эрт мэдэгдэх нь ойлгомжтой) ----
function updateInAppBrowserNotice(){
  if(!inAppBrowserNotice) return;
  var name = detectInAppBrowser();
  if(name){
    inAppBrowserNoticeText.textContent = 'Холбоосоо хуулж Chrome/Safari-д нээгээрэй, эсвэл доор и-мэйлээр бүртгүүлээрэй.';
    inAppBrowserNotice.classList.add('show');
  } else {
    inAppBrowserNotice.classList.remove('show');
  }
}

if(iabnCopyBtn){
  iabnCopyBtn.addEventListener('click', function(){
    var url = location.href;
    function showCopied(){
      iabnCopyBtn.textContent = 'Хуулагдлаа ✓';
      iabnCopyBtn.classList.add('copied');
      setTimeout(function(){
        iabnCopyBtn.textContent = 'Холбоос хуулах';
        iabnCopyBtn.classList.remove('copied');
      }, 1800);
    }
    if(navigator.clipboard && navigator.clipboard.writeText){
      navigator.clipboard.writeText(url).then(showCopied).catch(function(){
        fallbackCopy(url, showCopied);
      });
    } else {
      fallbackCopy(url, showCopied);
    }
  });
}

// ---- Clipboard API дэмжигдэхгүй (зарим хуучин in-app webview) орчинд
// зориулсан нөөц арга: түр textarea үүсгэж, сонгоод хуулна ----
function fallbackCopy(text, onDone){
  try{
    var ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.left = '-9999px';
    document.body.appendChild(ta);
    ta.focus();
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    if(onDone) onDone();
  }catch(e){}
}

// ---- Facebook/Messenger/Instagram зэрэг апп-н дотоод (in-app) browser
// (webview) илрүүлэх. Google эдгээр webview-үүдээс ирэх OAuth хүсэлтийг
// өөрөө (аюулгүй байдлын үүднээс) блоклодог тул popup нээгдэх ч алдааны
// хуудас гараад "цонхыг хаасан" мэт л харагддаг — иймд Firebase-ийг
// дуудахаас ӨМНӨ нь илрүүлж, ойлгомжтой заавар өгвөл илүү найдвартай. ----
function detectInAppBrowser(){
  var ua = navigator.userAgent || '';
  if(/FBAN|FBAV|FB_IAB|FBSV|Messenger/i.test(ua)) return 'Facebook/Messenger';
  if(/Instagram/i.test(ua)) return 'Instagram';
  if(/\bLine\//i.test(ua)) return 'LINE';
  if(/MicroMessenger/i.test(ua)) return 'WeChat';
  if(/TikTok|BytedanceWebview|musical_ly/i.test(ua)) return 'TikTok';
  if(/Twitter/i.test(ua)) return 'Twitter/X';
  if(/Snapchat/i.test(ua)) return 'Snapchat';
  // Android-ийн ерөнхий WebView (жишээ нь iOS-той адил тодорхой апп нэргүй
  // ч, Chrome биш webview дотор нээгдсэн үед UA-д "; wv)" гэж тэмдэглэгддэг)
  if(/; ?wv\)/i.test(ua)) return 'апп доторх';
  return null;
}

function inAppBrowserMessage(name){
  return 'Google энд ажиллахгүй. Холбоосоо Chrome/Safari-д нээгээрэй.';
}
