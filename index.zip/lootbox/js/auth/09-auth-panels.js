/* ==================================================================
   09-auth-panels.js — Нэвтрэх / Бүртгүүлэх / Мартсан панелуудыг солих
   ================================================================== */


// ---- Нууц үгийн товч устгагдсан тул текст талбар шууд харагдана ----
function showAllPagesHidden(){
  document.getElementById('mainView').style.display = 'none';
  document.getElementById('allGamesView').style.display = 'none';
  document.getElementById('profileView').style.display = 'none';
  document.getElementById('rechargeView').style.display = 'none';
  document.getElementById('notificationsView').style.display = 'none';
  document.getElementById('searchView').style.display = 'none';
}

function getCurrentVisiblePage(){
  var ids = ['mainView', 'allGamesView', 'profileView', 'rechargeView', 'notificationsView', 'searchView'];
  for(var i=0;i<ids.length;i++){
    var el = document.getElementById(ids[i]);
    if(el && el.style.display !== 'none') return el;
  }
  return null;
}

function showAuthPanel(which){
  loginPanel.style.display = which === 'login' ? 'block' : 'none';
  registerPanel.style.display = which === 'register' ? 'block' : 'none';
  forgotPanel.style.display = which === 'forgot' ? 'block' : 'none';
  tabLogin.classList.toggle('active', which === 'login');
  tabRegister.classList.toggle('active', which === 'register');
  var tabsRow = tabLogin.parentElement;
  tabsRow.style.display = (which === 'forgot') ? 'none' : 'flex';
  // Өмнөх оролдлогоос үлдсэн хуучин сануулга (жишээ нь "Имэйл хаягаа оруулна уу") шинэ
  // хэсэг рүү шилжихэд дагаж харагдахгүй байхаар цэвэрлэнэ
  if(which === 'login'){
    loginError.style.display = 'none';
    clearFieldError(loginUsernameError);
    clearFieldError(loginPasswordError);
    loginUsername.classList.remove('field-invalid');
    loginPassword.classList.remove('field-invalid');
  } else if(which === 'register'){
    registerError.style.display = 'none';
    clearFieldError(registerUsernameError);
    clearFieldError(registerEmailError);
    clearFieldError(registerPasswordError);
    clearFieldError(registerPassword2Error);
    registerUsername.classList.remove('field-invalid');
    registerEmail.classList.remove('field-invalid');
    registerPassword.classList.remove('field-invalid');
    registerPassword2.classList.remove('field-invalid');
    updateRegisterBtn();
  }
}
