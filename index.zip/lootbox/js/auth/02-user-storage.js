/* ==================================================================
   02-user-storage.js — Хэрэглэгчийн бүртгэлийн сан (localStorage)
   ================================================================== */


// ---- Хэрэглэгчийн бүртгэлийн сан (localStorage-д жинхэнэ хадгалагдана) ----
var USERS_KEY = 'rewardhub_users';

function loadUsers(){
  try{
    return JSON.parse(localStorage.getItem(USERS_KEY)) || {};
  }catch(e){ return {}; }
}

function saveUsers(users){
  try{
    localStorage.setItem(USERS_KEY, JSON.stringify(users));
    return true;
  }catch(e){
    return false;
  }
}
