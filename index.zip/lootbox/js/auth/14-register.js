/* ==================================================================
   14-register.js — Бүртгүүлэх + формын шалгалт
   ================================================================== */


// ---- Хэрэглэгчийн нэр (username) давхцаж байгаа эсэхийг шалгах ----
// excludeKey дамжуулбал (жишээ нь: профайлаа засаж буй одоогийн
// хэрэглэгчийн key) тухайн хэрэглэгчийн өөрийнх нь бичлэгийг харгалзахгүй
// тул хэрэглэгч өөрийн хуучин нэрээ өөрчлөлгүй дахин хадгалж болно.
function isUsernameTaken(username, excludeKey){
  var users = loadUsers();
  var normalized = username.trim().toLowerCase();
  for(var key in users){
    if(excludeKey && key === excludeKey) continue;
    if(users.hasOwnProperty(key) && users[key].displayName && users[key].displayName.trim().toLowerCase() === normalized){
      return true;
    }
  }
  return false;
}

function doRegister(){
  if(registerBtn.disabled) return; // хүсэлт аль хэдийн явж байгаа бол давхар бүү илгээ
  var u = registerUsername.value.trim();
  var email = registerEmail.value.trim();
  var p = registerPassword.value;
  var p2 = registerPassword2.value;
  registerError.style.display = 'none';
  clearFieldError(registerUsernameError);
  clearFieldError(registerEmailError);
  clearFieldError(registerPasswordError);
  clearFieldError(registerPassword2Error);
  if(!u){
    setFieldError(registerUsernameError, 'Хэрэглэгчийн нэрээ оруулна уу');
    highlightInvalidField(registerUsername, registerUsernameError);
    return;
  }
  if(isUsernameTaken(u)){
    setFieldError(registerUsernameError, 'Энэ хэрэглэгчийн нэр аль хэдийн ашиглагдсан байна');
    highlightInvalidField(registerUsername, registerUsernameError);
    return;
  }
  if(!email){
    setFieldError(registerEmailError, 'Имэйл хаягаа оруулна уу');
    highlightInvalidField(registerEmail, registerEmailError);
    return;
  }
  var emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  if(!emailOk){
    setFieldError(registerEmailError, 'Зөв имэйл хаяг оруулна уу');
    highlightInvalidField(registerEmail, registerEmailError);
    return;
  }
  if(!p){
    setFieldError(registerPasswordError, 'Нууц үгээ оруулна уу');
    highlightInvalidField(registerPassword, registerPasswordError);
    return;
  }
  if(p.length < 6){
    setFieldError(registerPasswordError, 'Нууц үг дор хаяж 6 тэмдэгт байх ёстой');
    highlightInvalidField(registerPassword, registerPasswordError);
    return;
  }
  if(!p2){
    setFieldError(registerPassword2Error, 'Нууц үгээ давтан оруулна уу');
    highlightInvalidField(registerPassword2, registerPassword2Error);
    return;
  }
  if(p !== p2){
    setFieldError(registerPassword2Error, 'Нууц үг таарахгүй байна');
    highlightInvalidField(registerPassword2, registerPassword2Error);
    return;
  }
  setBtnLoading(registerBtn);
  firebase.auth().createUserWithEmailAndPassword(email, p)
    .then(function(cred){
      return cred.user.updateProfile({ displayName: u }).then(function(){ return cred.user; });
    })
    .then(function(user){
      var users = loadUsers();
      var record = { displayName: u, email: email, avatarImg: null, provider: 'password', purchases: [] };
      users[user.uid] = record;
      saveUsers(users);
      // Бүртгүүлмэгц шууд нэвтрүүлэхгүй: Firebase өөрөө автоматаар нэвтрүүлдэг тул
      // гарган, хэрэглэгчийг Нэвтрэх хэсэг рүү шилжүүлж, өөрөө имэйл/нууц үгээ
      // дахин оруулж нэвтрэхийг шаардана.
      return firebase.auth().signOut().catch(function(){}).then(function(){
        resetBtn(registerBtn, 'Бүртгүүлэх');
        registerUsername.value = '';
        registerEmail.value = '';
        registerPassword.value = '';
        registerPassword2.value = '';
        registerError.style.display = 'none';
        updateRegisterBtn();
        showAuthPanel('login');
        loginUsername.value = email;
        loginPassword.value = '';
        loginError.style.display = 'none';
        showToast('Бүртгэл амжилттай үүслээ', 'Имэйл болон нууц үгээрээ нэвтэрнэ үү.');
      });
    })
    .catch(function(err){
      resetBtn(registerBtn, 'Бүртгүүлэх');
      updateRegisterBtn();
      var code = err && err.code;
      var msg = firebaseErrorMessage(err);
      if(code === 'auth/email-already-in-use' || code === 'auth/invalid-email'){
        setFieldError(registerEmailError, msg);
        highlightInvalidField(registerEmail, registerEmailError);
      } else if(code === 'auth/weak-password'){
        setFieldError(registerPasswordError, msg);
        highlightInvalidField(registerPassword, registerPasswordError);
      } else {
        setRegisterError(msg);
      }
    });
}

registerBtn.addEventListener('click', doRegister);

registerPassword2.addEventListener('keydown', function(e){
  if(e.key === 'Enter') doRegister();
});

// ---- Бүртгүүлэх товч: мэдээлэл бүрэн, зөв оруулагдсан үед л идэвхтэй (өнгө нь хэвийн), эс бөгөөс саарал/дарагдахгүй ----
var REGISTER_EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function isRegisterFormValid(){
  var u = registerUsername.value.trim();
  var email = registerEmail.value.trim();
  var p = registerPassword.value;
  var p2 = registerPassword2.value;
  if(!u || isUsernameTaken(u)) return false;
  if(!REGISTER_EMAIL_RE.test(email)) return false;
  if(p.length < 6) return false;
  if(!p2 || p !== p2) return false;
  return true;
}

function updateRegisterBtn(){
  if(registerBtn.classList.contains('loading')) return; // хүсэлт явж байх үед loading төлөвийг бүү өөрчил
  registerBtn.disabled = !isRegisterFormValid();
}

// Талбараас гарах үед (blur) буруу бичсэн утгын шалтгааныг тухайн талбарын доор харуулна
function showFieldMsg(errorEl, msg){ if(msg){ setFieldError(errorEl, msg); } else { clearFieldError(errorEl); } }

function usernameMsg(){ var u = registerUsername.value.trim(); return (u && isUsernameTaken(u)) ? 'Энэ хэрэглэгчийн нэр аль хэдийн ашиглагдсан байна' : ''; }

function emailMsg(){ var e = registerEmail.value.trim(); return (e && !REGISTER_EMAIL_RE.test(e)) ? 'Зөв имэйл хаяг оруулна уу' : ''; }

function passwordMsg(){ var p = registerPassword.value; return (p && p.length < 6) ? 'Нууц үг дор хаяж 6 тэмдэгт байх ёстой' : ''; }

function password2Msg(){ var p2 = registerPassword2.value; return (p2 && p2 !== registerPassword.value) ? 'Нууц үг таарахгүй байна' : ''; }

[registerUsername, registerEmail, registerPassword, registerPassword2].forEach(function(inp){
  inp.addEventListener('input', updateRegisterBtn);
  inp.addEventListener('change', updateRegisterBtn);
});

registerUsername.addEventListener('input', function(){ clearFieldError(registerUsernameError); });

registerEmail.addEventListener('input', function(){ clearFieldError(registerEmailError); });

registerPassword.addEventListener('input', function(){ clearFieldError(registerPasswordError); });

registerPassword2.addEventListener('input', function(){ clearFieldError(registerPassword2Error); });

registerUsername.addEventListener('blur', function(){ showFieldMsg(registerUsernameError, usernameMsg()); });

registerEmail.addEventListener('blur', function(){ showFieldMsg(registerEmailError, emailMsg()); });

registerPassword.addEventListener('blur', function(){
  showFieldMsg(registerPasswordError, passwordMsg());
  if(registerPassword2.value) showFieldMsg(registerPassword2Error, password2Msg());
});

registerPassword2.addEventListener('blur', function(){ showFieldMsg(registerPassword2Error, password2Msg()); });

updateRegisterBtn();
