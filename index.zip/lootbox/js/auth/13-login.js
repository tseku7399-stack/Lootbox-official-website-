/* ==================================================================
   13-login.js — Нэвтрэх (имэйл/нууц үг)
   ================================================================== */


function doLogin(){
  if(loginBtn.disabled) return; // хүсэлт аль хэдийн явж байгаа бол (жишээ нь Enter товчийг давхар дарсан) дахин бүү илгээ
  var email = loginUsername.value.trim();
  var p = loginPassword.value;
  hideToast();
  loginError.style.display = 'none';
  clearFieldError(loginUsernameError);
  clearFieldError(loginPasswordError);
  if(!email){
    setFieldError(loginUsernameError, 'Имэйл хаягаа оруулна уу');
    highlightInvalidField(loginUsername, loginUsernameError);
    return;
  }
  var emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  if(!emailOk){
    setFieldError(loginUsernameError, 'Зөв имэйл хаяг оруулна уу');
    highlightInvalidField(loginUsername, loginUsernameError);
    return;
  }
  if(!p){
    setFieldError(loginPasswordError, 'Нууц үгээ оруулна уу');
    highlightInvalidField(loginPassword, loginPasswordError);
    return;
  }
  setBtnLoading(loginBtn);
  firebase.auth().signInWithEmailAndPassword(email, p)
    .then(function(cred){
      resetBtn(loginBtn, 'Нэвтрэх');
      var kr = getOrCreateLocalRecord(cred.user);
      completeAuth(kr.key, kr.record);
    })
    .catch(function(err){
      resetBtn(loginBtn, 'Нэвтрэх');
      var code = err && err.code;
      var msg = firebaseErrorMessage(err);
      if(code === 'auth/user-not-found' || code === 'auth/invalid-email'){
        setFieldError(loginUsernameError, msg);
        highlightInvalidField(loginUsername, loginUsernameError);
      } else if(code === 'auth/wrong-password' || code === 'auth/invalid-credential'){
        setFieldError(loginPasswordError, msg);
        highlightInvalidField(loginPassword, loginPasswordError);
      } else {
        setLoginError(msg);
      }
    });
}

loginBtn.addEventListener('click', doLogin);

loginPassword.addEventListener('keydown', function(e){
  if(e.key === 'Enter') doLogin();
});
