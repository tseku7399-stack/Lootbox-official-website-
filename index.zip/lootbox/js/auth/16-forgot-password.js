/* ==================================================================
   16-forgot-password.js — Нууц үг сэргээх
   ================================================================== */


function doForgot(){
  if(forgotBtn.disabled) return; // хүсэлт аль хэдийн явж байгаа бол давхар бүү илгээ
  var v = forgotInput.value.trim();
  if(!v){
    forgotError.textContent = 'Талбарыг бөглөнө үү';
    forgotError.style.display = 'block';
    forgotSent.style.display = 'none';
    highlightInvalidField(forgotInput);
    return;
  }
  var emailOk = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
  if(!emailOk){
    forgotError.textContent = 'Зөв имэйл хаяг оруулна уу';
    forgotError.style.display = 'block';
    forgotSent.style.display = 'none';
    highlightInvalidField(forgotInput);
    return;
  }
  forgotError.style.display = 'none';
  forgotBtn.disabled = true;
  firebase.auth().sendPasswordResetEmail(v)
    .then(function(){
      forgotBtn.disabled = false;
      forgotSent.style.display = 'block';
    })
    .catch(function(err){
      forgotBtn.disabled = false;
      forgotError.textContent = firebaseErrorMessage(err);
      forgotError.style.display = 'block';
      forgotSent.style.display = 'none';
      highlightInvalidField(forgotInput);
    });
}

forgotBtn.addEventListener('click', doForgot);

forgotInput.addEventListener('keydown', function(e){
  if(e.key === 'Enter') doForgot();
});
