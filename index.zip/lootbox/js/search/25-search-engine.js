/* ==================================================================
   25-search-engine.js — Хайлтын алгоритм: монгол/кирилл-латин хөрвүүлэлт, ижил төстэй байдал
   ================================================================== */


// <pure>
// Кирилл бичлэгээр хайдаг хэрэглэгчдэд зориулсан Кирилл нэрс (data-game-ээр)
var SEARCH_BUILTIN_ALIASES = {
  'PUBG Mobile': ['pubg','pubgm','pubg mobile','battlegrounds','пубг','пабг','пубжи','пубг мобайл','пабг мобайл'],
  'MLBB': ['mlbb','ml','mobile legends','mobile legends bang bang','млбб','мл','мобайл легенд','мобайл легендс','мобайл легендз','мобайл легенд бэнг бэнг','легенд'],
  'Standoff 2': ['standoff','standoff 2','standoff2','so2','стандофф','стэндофф','стендофф','стандоф','стандофф 2','стэндофф 2'],
  'Roblox': ['roblox','роблокс','роблох','роблакс'],
  'Valorant': ['valorant','valo','riot','vp','валорант','валарант','вало','райот'],
  'Magic Chess': ['magic chess','magic chess go go','mcgg','go go','мажик чесс','мэжик чесс','меджик чесс','мажик чэс','мэжик чэс','мэжик чесс гоу гоу','чесс','чэс','гоу гоу','го го']
};

function searchHasCyr(s){ return /[\u0400-\u04ff]/.test(s); }

function searchNorm(str){
  var s = String(str == null ? '' : str).toLowerCase();
  if(s.normalize){
    // зөвхөн латин үсгийн диакритик (é -> e) арилгана; Кирилл й, ө, ү, ё хэвээр үлдэнэ
    s = s.replace(/[\u00c0-\u024f]+/g, function(chunk){
      try{ return chunk.normalize('NFKD').replace(/[\u0300-\u036f]/g, ''); }catch(e){ return chunk; }
    });
  }
  return s.replace(/[^a-z0-9\u0400-\u04ff]+/g, ' ').replace(/\s+/g, ' ').trim();
}

// Levenshtein зай (хоёр зэргэлдээ үсгийн байр солигдохыг 1 алдаа гэж тооцно: pugb -> pubg)
function searchLev(a, b){
  if(a === b) return 0;
  if(!a.length) return b.length;
  if(!b.length) return a.length;
  var prev2 = null, prev = [], cur = [], i, j;
  for(j = 0; j <= b.length; j++) prev[j] = j;
  for(i = 1; i <= a.length; i++){
    cur = [i];
    for(j = 1; j <= b.length; j++){
      cur[j] = Math.min(prev[j] + 1, cur[j-1] + 1, prev[j-1] + (a.charAt(i-1) === b.charAt(j-1) ? 0 : 1));
      if(i > 1 && j > 1 && a.charAt(i-1) === b.charAt(j-2) && a.charAt(i-2) === b.charAt(j-1)){
        cur[j] = Math.min(cur[j], prev2[j-2] + 1);
      }
    }
    prev2 = prev;
    prev = cur;
  }
  return prev[b.length];
}

// q: хайх үг (normalize хийсэн), t: нэг нэр/alias (normalize хийсэн). Оноо 0 = таарахгүй
function searchScoreTerm(q, t, noSub){
  if(!q || !t) return 0;
  var qc = q.replace(/ /g, ''), tc = t.replace(/ /g, '');
  if(t === q) return 100;
  if(tc === qc) return 98;
  if(t.indexOf(q) === 0) return 90;
  if(qc.length >= 2 && tc.indexOf(qc) === 0) return 85;
  var words = t.split(' '), i, j;
  for(i = 0; i < words.length; i++){ if(words[i].indexOf(q) === 0) return 75; }
  // олон үгтэй хайлт: үг бүр нэрийн аль нэг үгийн эхлэлтэй таарвал
  var qw = q.split(' ');
  if(qw.length > 1){
    var all = true;
    for(j = 0; j < qw.length && all; j++){
      var hit = false;
      for(i = 0; i < words.length; i++){ if(words[i].indexOf(qw[j]) === 0){ hit = true; break; } }
      if(!hit) all = false;
    }
    if(all) return 70;
  }
  // noSub: товчилсон/өөр нэр (alias) нь тоглоомын жинхэнэ нэр биш тул дундаас нь таарахгүй
  if(!noSub){
    if(t.indexOf(q) !== -1) return 60;
    if(qc.length >= 3 && tc.indexOf(qc) !== -1) return 55;
  }
  // үсгийн алдаа (typo): нийт нэр болон үг тус бүртэй харьцуулна
  if(qc.length >= 4){
    var maxD = qc.length >= 8 ? 2 : 1, best = 99, d;
    d = searchLev(qc, tc); if(d < best) best = d;
    for(i = 0; i < words.length; i++){
      if(words[i].length >= 3){
        d = searchLev(qc, words[i]); if(d < best) best = d;
        if(words[i].length > qc.length){
          d = searchLev(qc, words[i].substring(0, qc.length)); if(d < best) best = d;
        }
      }
    }
    if(best <= maxD) return 40 - best * 5;
  }
  return 0;
}

// terms: тоглоомын нэрүүд (нэрний аль ч хэсгээс таарна). aliasTerms: товчилсон/өөр нэрс
// (эхлэлээр л таарна: "riot" гэх мэт нэр нь биш үсгээр Valorant гарахгүй).
// Хайлт болон нэр ХОЁР ИЖИЛ үсгийн төрөлтэй (латин-латин, Кирилл-Кирилл) байхад л
// харьцуулагдана; харагдахдаа адил үсэг ч (p/р, a/а, o/о, c/с, e/е, x/х) өөр үсэг.
function searchScoreEntry(rawQuery, terms, aliasTerms){
  var q = searchNorm(rawQuery);
  if(!q) return 0;
  var best = 0, i, sc;
  for(i = 0; i < terms.length; i++){
    sc = searchScoreTerm(q, terms[i], false);
    if(sc > best) best = sc;
  }
  if(aliasTerms){
    for(i = 0; i < aliasTerms.length; i++){
      sc = searchScoreTerm(q, aliasTerms[i], true);
      if(sc > best) best = sc;
    }
  }
  return best;
}

// </pure>
function searchEscHtml(v){
  return String(v == null ? '' : v).replace(/[&<>"']/g, function(c){
    return { '&':'&amp;', '<':'&lt;', '>':'&gt;', '"':'&quot;', "'":'&#39;' }[c];
  });
}

// DOM-оос тоглоомын жагсаалтыг (data-game тус бүрээр нэгээр) шинээр уншина
function getSearchEntries(){
  var seen = {}, list = [];
  var cards = document.querySelectorAll('.offer-card[data-game]');
  for(var i = 0; i < cards.length; i++){
    var card = cards[i];
    var name = card.getAttribute('data-game');
    if(!name || seen[name]) continue;
    seen[name] = true;
    var cover = card.querySelector('.offer-cover');
    var titleEl = card.querySelector('.title');
    var titleText = titleEl ? titleEl.textContent : '';
    var nameRaw = [name, card.getAttribute('data-display-name'), card.getAttribute('data-search-name'), titleText];
    var aliasRaw = [];
    var aliasAttr = card.getAttribute('data-aliases');
    if(aliasAttr) aliasRaw = aliasRaw.concat(aliasAttr.split(','));
    if(SEARCH_BUILTIN_ALIASES[name]) aliasRaw = aliasRaw.concat(SEARCH_BUILTIN_ALIASES[name]);
    var terms = [], aliasTerms = [], dedupe = {}, k, nt;
    for(k = 0; k < nameRaw.length; k++){
      nt = searchNorm(nameRaw[k]);
      if(nt && !dedupe[nt]){ dedupe[nt] = true; terms.push(nt); }
    }
    // Кирилл бичлэг нь тоглоомын нэрийн Кирилл хувилбар тул нэрээр нь (бүх хэсгээс) хайна;
    // латин товчлол/өөр нэр нь зөвхөн эхлэлээр таарна
    for(k = 0; k < aliasRaw.length; k++){
      nt = searchNorm(aliasRaw[k]);
      if(!nt || dedupe[nt]) continue;
      dedupe[nt] = true;
      if(searchHasCyr(nt)) terms.push(nt); else aliasTerms.push(nt);
    }
    list.push({
      name: name,
      label: card.getAttribute('data-search-name') || card.getAttribute('data-display-name') || (titleText && titleText.trim()) || name,
      el: card,
      terms: terms,
      aliasTerms: aliasTerms,
      order: i,
      iconHtml: cover ? cover.innerHTML : ''
    });
  }
  return list;
}
