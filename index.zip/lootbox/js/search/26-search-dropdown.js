/* ==================================================================
   26-search-dropdown.js — Тоглоом хайх талбар ба dropdown жагсаалт
   ================================================================== */


// ---- Тоглоом хайх: талбарт шууд бичихэд, доор нь dropdown жагсаалт нээгдэнэ ----
// Латин болон Кирилл үсэг НЭГ НЭГЭЭРЭЭ тусдаа: латин бичсэн хайлт зөвхөн латин нэрээс,
// Кирилл бичсэн хайлт зөвхөн Кирилл нэрээс хайна (латин p ≠ Кирилл р, a ≠ а гэх мэт
// харагдахдаа адилхан үсгүүд хэзээ ч андуурагдахгүй). Зай/зураас/цэг таслалыг үл тооно
// (magicchess = Magic Chess), 1-2 үсгийн алдааг (valarant, robolx) зөвшөөрч, илүү
// тохирохыг дээр нь эрэмбэлнэ. Жагсаалтыг хайлт болгонд DOM-оос шинээр уншдаг тул админ самбараас
// тоглоомын нэр солигдсон ч шууд тусна.
var gameSearchInput = document.getElementById('gameSearchInput');

var gameSearchClear = document.getElementById('gameSearchClear');

var homeSearchBox = document.getElementById('homeSearchBox');

var homeSearchDropdown = document.getElementById('homeSearchDropdown');

var searchResults = [];

var searchActive = -1;

function setSearchActive(idx){
  var items = homeSearchDropdown.querySelectorAll('.search-dropdown-item');
  searchActive = idx;
  for(var i = 0; i < items.length; i++){
    var on = (i === idx);
    items[i].classList.toggle('active', on);
    items[i].setAttribute('aria-selected', on ? 'true' : 'false');
    if(on && items[i].scrollIntoView){ try{ items[i].scrollIntoView({ block:'nearest' }); }catch(e){} }
  }
}

function renderHomeSearchDropdown(query){
  var q = String(query || '');
  if(gameSearchClear) gameSearchClear.style.display = q.length ? 'flex' : 'none';
  if(searchNorm(q) === ''){
    searchResults = [];
    searchActive = -1;
    homeSearchDropdown.innerHTML = '';
    closeHomeSearchDropdown();
    return;
  }
  var scored = [];
  getSearchEntries().forEach(function(entry){
    var s = searchScoreEntry(q, entry.terms, entry.aliasTerms);
    if(s > 0){ entry.score = s; scored.push(entry); }
  });
  scored.sort(function(a, b){ return (b.score - a.score) || (a.order - b.order); });
  searchResults = scored;
  searchActive = -1;
  if(scored.length === 0){
    homeSearchDropdown.innerHTML = '<div class="search-dropdown-empty">Тоглоом олдсонгүй</div>';
  } else {
    homeSearchDropdown.innerHTML = scored.map(function(r, i){
      return '<div class="search-dropdown-item" role="option" aria-selected="false" data-idx="' + i + '">' +
               '<div class="search-dropdown-icon">' + r.iconHtml + '</div>' +
               '<div class="search-dropdown-name">' + searchEscHtml(r.label) + '</div>' +
             '</div>';
    }).join('');
  }
  homeSearchDropdown.classList.add('open');
}

function openHomeSearchDropdown(){
  renderHomeSearchDropdown(gameSearchInput.value);
}

function closeHomeSearchDropdown(){
  homeSearchDropdown.classList.remove('open');
  searchActive = -1;
}

function chooseSearchResult(entry){
  if(!entry) return;
  closeHomeSearchDropdown();
  gameSearchInput.value = '';
  if(gameSearchClear) gameSearchClear.style.display = 'none';
  searchResults = [];
  try{ gameSearchInput.blur(); }catch(e){}
  entry.el.click();
}

homeSearchDropdown.setAttribute('role', 'listbox');

// Жагсаалтыг дарахад input-ийн focus алдагдаж dropdown хаагдахаас сэргийлнэ
homeSearchDropdown.addEventListener('mousedown', function(e){ e.preventDefault(); });

homeSearchDropdown.addEventListener('click', function(e){
  var node = e.target;
  while(node && node !== homeSearchDropdown && !(node.classList && node.classList.contains('search-dropdown-item'))){
    node = node.parentNode;
  }
  if(!node || node === homeSearchDropdown) return;
  var idx = parseInt(node.getAttribute('data-idx'), 10);
  if(!isNaN(idx)) chooseSearchResult(searchResults[idx]);
});

var searchComposing = false;

gameSearchInput.addEventListener('focus', openHomeSearchDropdown);

gameSearchInput.addEventListener('compositionstart', function(){ searchComposing = true; });

gameSearchInput.addEventListener('compositionend', function(){
  searchComposing = false;
  renderHomeSearchDropdown(gameSearchInput.value);
});

gameSearchInput.addEventListener('input', function(){
  if(searchComposing) return;
  renderHomeSearchDropdown(gameSearchInput.value);
});

gameSearchInput.addEventListener('keydown', function(e){
  var key = e.key;
  var isOpen = homeSearchDropdown.classList.contains('open');
  if(key === 'ArrowDown' || key === 'ArrowUp'){
    if(!isOpen){ renderHomeSearchDropdown(gameSearchInput.value); return; }
    if(!searchResults.length) return;
    e.preventDefault();
    var n = searchResults.length;
    var next = key === 'ArrowDown' ? (searchActive + 1) % n : (searchActive <= 0 ? n - 1 : searchActive - 1);
    setSearchActive(next);
  } else if(key === 'Enter'){
    if(searchComposing) return;
    e.preventDefault();
    if(!isOpen) renderHomeSearchDropdown(gameSearchInput.value);
    if(searchResults.length) chooseSearchResult(searchResults[searchActive >= 0 ? searchActive : 0]);
  } else if(key === 'Escape'){
    closeHomeSearchDropdown();
  }
});

if(gameSearchClear){
  gameSearchClear.addEventListener('mousedown', function(e){ e.preventDefault(); });
  gameSearchClear.addEventListener('click', function(){
    gameSearchInput.value = '';
    renderHomeSearchDropdown('');
    try{ gameSearchInput.focus(); }catch(e){}
  });
}

document.addEventListener('click', function(e){
  if(!homeSearchBox.contains(e.target)) closeHomeSearchDropdown();
});
