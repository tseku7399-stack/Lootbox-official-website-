/* ==================================================================
   21-notification-list.js — Мэдэгдлийн хуудас: жагсаалт зурах, нээх, устгах
   ================================================================== */


function renderNotifications(){
  var list = document.getElementById('notifList');
  if(!list) return;
  if(NOTIFICATIONS.length === 0){
    list.innerHTML = '<div class="notif-empty">Мэдэгдэл алга байна</div>';
  } else {
    list.innerHTML = NOTIFICATIONS.map(function(n, i){
      var clickableClass = ' clickable';
      return '<div class="notif-item' + (n.unread ? ' unread' : '') + clickableClass + '" data-notif-index="' + i + '">' +
        '<div class="notif-body">' +
          '<div class="notif-row"><div class="notif-title"><span>' + n.title + '</span></div><div class="notif-time">' + n.time + '</div></div>' +
          '<div class="notif-desc">' + n.body + '</div>' +
        '</div>' +
        '<div class="notif-del" data-notif-del="' + i + '" aria-label="Устгах">' +
          '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>' +
        '</div>' +
      '</div>';
    }).join('');
    list.querySelectorAll('.notif-item[data-notif-index]').forEach(function(itemEl){
      itemEl.addEventListener('click', function(){
        var idx = parseInt(itemEl.getAttribute('data-notif-index'), 10);
        var n = NOTIFICATIONS[idx];
        if(n && n.unread){
          n.unread = false;
          itemEl.classList.remove('unread');
          saveNotifications();
          updateNotifDot();
        }
        if(n && n.purchase) openPurchaseDetail(n.purchase);
      });
    });
    list.querySelectorAll('.notif-del[data-notif-del]').forEach(function(delEl){
      delEl.addEventListener('click', function(e){
        e.stopPropagation();
        var idx = parseInt(delEl.getAttribute('data-notif-del'), 10);
        NOTIFICATIONS.splice(idx, 1);
        saveNotifications();
        renderNotifications();
      });
    });
  }
  updateNotifDot();
}

function updateNotifDot(){
  var dot = document.getElementById('notifDot');
  if(!dot) return;
  var unreadCount = NOTIFICATIONS.filter(function(n){ return n.unread; }).length;
  if(unreadCount > 0){
    dot.textContent = unreadCount > 99 ? '99+' : String(unreadCount);
    dot.style.display = 'flex';
  } else {
    dot.textContent = '';
    dot.style.display = 'none';
  }
}

var notifOpenedFrom = null;

function openNotifications(){
  notifOpenedFrom = getCurrentVisiblePage() || document.getElementById('mainView');
  showAllPagesHidden();
  renderNotifications();
  document.getElementById('notificationsView').style.display = 'block';
}

document.getElementById('notifBell').addEventListener('click', function(e){
  e.stopPropagation();
  openNotifications();
});

document.getElementById('notifClearBtn').addEventListener('click', function(e){
  e.stopPropagation();
  NOTIFICATIONS.length = 0;
  saveNotifications();
  renderNotifications();
});

var notifBackBtn = document.getElementById('notifBackBtn');

if(notifBackBtn){
  notifBackBtn.addEventListener('click', function(){
    document.getElementById('notificationsView').style.display = 'none';
    if(notifOpenedFrom) notifOpenedFrom.style.display = 'block';
    else document.getElementById('mainView').style.display = 'block';
  });
}

renderNotifications();
