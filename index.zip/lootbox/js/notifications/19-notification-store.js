/* ==================================================================
   19-notification-store.js — Мэдэгдлийн хадгалалт (localStorage)
   ================================================================== */


var NOTIF_ICONS = {
  diamond:'<svg viewBox="0 0 24 24" fill="currentColor"><path d="M4.5 9L12 3l7.5 6-7.5 12z"/></svg>',
  gift:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="8" width="18" height="13" rx="2"/><path d="M3 12h18M12 8v13"/><path d="M12 8C10.5 5 7 4 7 6.5S9.5 8 12 8Zm0 0c1.5-3 5-4 5-1.5S14.5 8 12 8Z"/></svg>',
  bellIcon:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8a6 6 0 0 0-12 0c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 0 1-3.4 0"/></svg>',
  check:'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/></svg>'
};

// Жинхэнэ (амжилттай худалдан авалт хийх бүрд автоматаар нэмэгддэг)
// мэдэгдлүүд энд орно. Урьд байсан хуурамч жишээ мэдэгдлүүдийг хассан.
// localStorage-д хадгалж, сайтыг restart/refresh хийсэн ч алдагдахгүй,
// зөвхөн хэрэглэгч "Бүгдийг устгах" эсвэл тухайн мэдэгдэл дээрх устгах
// товч дарж ЗОРИУДЛАН устгасан үед л алга болно.
var NOTIF_STORAGE_KEY = 'lootbox_notifications';

function loadStoredNotifications(){
  try{
    var raw = JSON.parse(localStorage.getItem(NOTIF_STORAGE_KEY));
    return Array.isArray(raw) ? raw : [];
  }catch(e){ return []; }
}

function saveNotifications(){
  try{ localStorage.setItem(NOTIF_STORAGE_KEY, JSON.stringify(NOTIFICATIONS)); }catch(e){}
}

var NOTIFICATIONS = loadStoredNotifications();
