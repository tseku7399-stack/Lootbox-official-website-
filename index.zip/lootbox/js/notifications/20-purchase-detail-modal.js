/* ==================================================================
   20-purchase-detail-modal.js — Худалдан авалтын дэлгэрэнгүй цонх
   ================================================================== */


// Мэдэгдэл дэх худалдан авалтын мэдээллийг ЗОРИУДЛАН "Худалдан авалт
// амжилттай" (checkmark) дэлгэцээс өөр, баримт (receipt) маягийн тусдаа
// modal-аар харуулна.
function openPurchaseDetail(purchase){
  document.getElementById('ndGameName').textContent = purchase.game || '—';
  document.getElementById('ndAccId').textContent = purchase.accId || '—';
  document.getElementById('ndAccName').textContent = purchase.accName || '—';
  document.getElementById('ndItemName').textContent = purchase.item || '—';
  document.getElementById('ndDate').textContent = purchase.date || '—';
  document.getElementById('ndAmount').textContent = purchase.price || '—';
  var overlay = document.getElementById('notifDetailOverlay');
  if(overlay) overlay.classList.add('open');
}

(function initNotifDetailModal(){
  var overlay = document.getElementById('notifDetailOverlay');
  var closeBtn = document.getElementById('notifDetailClose');
  if(!overlay || !closeBtn) return;
  function close(){ overlay.classList.remove('open'); }
  closeBtn.addEventListener('click', close);
  overlay.addEventListener('click', function(e){
    if(e.target === overlay) close();
  });
})();
