# LootBox сайт — файлын бүтэц

Нэг том HTML файлыг бүрэлдэхүүн (component) бүрээр нь тусад нь файл болгосон.
Зургуудыг (Logo.png, UC.PNG, Pubgmbanner.PNG гэх мэт) `index.html`-тэй нэг хавтсанд байлгана.

## Хаанаас юуг засах вэ

| Засах зүйл | Файл |
|---|---|
| Өнгө, хувьсагч | `css/00-variables.css` |
| Light / Neon загвар | `css/01-themes.css` |
| Навбар | `css/10-navbar.css` |
| Hamburger цэс | `css/11-side-drawer.css` |
| Хайлт | `css/13-search.css`, `js/search/` |
| Banner | `css/14-banner.css`, `js/ui/36-banner-carousel.js` |
| Тоглоомын картууд | `css/15-games.css` |
| Цэнэглэх хуудас | `css/21-recharge.css`, `js/recharge/` |
| Багц, үнэ | `js/recharge/28-packages.js` |
| Профайл | `css/22-profile.css`, `js/profile/` |
| Төлбөрийн цонх | `css/30-payment-modal.css`, `js/payment/` |
| Банкны жагсаалт | `js/payment/31-payment-data.js` |
| Мэдэгдэл | `css/20-notifications.css`, `js/notifications/` |
| Тохиргоо | `css/32-settings-modal.css`, `js/settings/` |
| Нэвтрэх / Бүртгүүлэх | `css/40-login.css`, `js/auth/` |
| Toast мессеж | `css/41-toast.css`, `js/ui/08-toast.js` |
| Нээлтийн popup | `css/43-entrance-popup.css`, `js/ui/06-entrance-popup.js` |
| Firebase тохиргоо | `js/firebase/firebase-config.js` |
| HTML бүтэц, текст | `index.html` |

## Анхаарах дүрэм

1. `index.html` доторх `<link>` ба `<script>`-ийн ДАРААЛЛЫГ өөрчлөхгүй. Файлын нэрийн дугаар нь ажиллах дараалал.
2. `js/start/40-start-async-sources.js` үргэлж хамгийн сүүлд ажиллана (Firebase сесс, сайтын тохиргоо).
3. JS файлууд нэг хувьсагч, функцийн орчныг хуваалцдаг (хуучин нэг файл байсан тул). Функцийн нэрийг өөр файлд давхцуулж болохгүй.
4. Шинэ CSS файл нэмбэл `index.html`-д `50-views-layout.css`-ээс өмнө холбоно.
